killall -9 stressapptest
killall -9 tc_hbdk3
