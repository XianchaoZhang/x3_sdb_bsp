chmod +x uart_duplex
./uart_duplex -d /dev/ttyS1 -b 115200 &
