chmod +x uart_duplex
./uart_duplex -d /dev/ttyS2 -b 115200 &
