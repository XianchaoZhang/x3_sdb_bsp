export LD_LIBRARY_PATH=/app/libbpu_predict/
/app/bin/bpu_predict_test
