#1 bpu test process1
nohup /app/libbpu/HBDK3_MODEL_2K/run.sh >/userdata/bpu-pr1.log &
#2 bpu test process2
nohup /app/libbpu/HBDK3_MODEL_P0000/run.sh >/userdata/bpu-pr2.log &
