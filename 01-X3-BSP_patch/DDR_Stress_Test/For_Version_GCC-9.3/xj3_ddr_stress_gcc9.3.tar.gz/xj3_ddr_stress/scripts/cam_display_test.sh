#!/bin/sh

if [ -f ".cam_to_vio_test.log" ];then
	rm -f .cam_to_vio_test.log
fi

IAR_VIO_CONFIG_PATH="/etc/vio"
VIO_APP_PATH="/app/bin"
CAMERA_CONFIG_PATH="/etc/cam"

interface_type=1
cam_index=2
info_type=6
loop=1
stop=1
start=1
free=1
get=1
dbg=0
status=0
mipi_check=1
process=0
pym_time=10
if_imx390=0
imx390_cam_index=0
imx390_log=1
press_test=0
test_3a=0

if_show_config=0
run_time=0

usage(){
	echo "Usage: ./cam_to_vio_test.sh"
	echo "Options:"
	echo "Required:"
	echo "-o [output type: hdmi or lcd]"
	echo "-b [board type: x2dev or j2dev]"
	echo "-c [camera type: imx390 or dual]"
	echo "-t [run time measured in seconds, doubled for dual camera]"
	echo "Functional:"
	echo "-i show detailed configuration used for vio_test"
	echo "-h show help message"
	echo "Optional: "
	echo "-a [iar config file you want to use]"
	echo "pass extra config for vio_test(7 for imx390, 15 otherwise - runtime excluded)."
	echo "          Please pass full config(including file name for vio/cam configs) in order."
	show_config 1
	exit 1
}

show_config(){
	echo "Camera type: $cam_type"
	if [ $if_imx390 -eq 0 ] || [ $1 -eq 1 ];then
		echo "Configs for vio_test:"
		echo "  -I interface type = $interface_type"
		echo "  -r run time       = $run_time"
		echo "  -v vio_config     = $VIO_CONFIG"
		echo "  -c cam_config     = $CAM_CONFIG"
		echo "  -i cam_index      = $cam_index"
		echo "  -t info_type      = $info_type"
		echo "  -l loop_needed    = $loop"
		echo "  -s stop_needed    = $stop"
		echo "  -p start_needed   = $start"
		echo "  -f free_data      = $free"
		echo "  -g get_info       = $get"
		echo "  -d debug_info     = $dbg"
		echo "  -S status_info    = $status"
		echo "  -C if mipi check  = $mipi_check"
		echo "  -P pym process    = $process"
		echo "  -T pym_time       = $pym_time"
	fi

	if [ $if_imx390 -eq 1 ] || [ $1 -eq 1 ];then
		if [ $1 -eq 0 ];then
			echo "  -r run time       = $run_time"
			echo "  -v vio_config     = $VIO_CONFIG"
			echo "  -c cam_config     = $CAM_CONFIG"
			echo "  -i cam_index      = $cam_index"
		fi
		echo "## imx390 exclusive configs. ##"
		echo "  -M if_imx390      = $if_imx390"
		echo "  -L imx390_log     = $imx390_log"
		echo "  -R press_test     = $press_test"
		echo "  -A test_3a        = $test_3a"
	fi
}

err_check(){
	if [ $? -ne 0 ];then
		echo "\"$1\" run failed!"
		echo "Please check if params are correct and config files are in the right place."
		if [ $1 = "vio_test" ];then
			echo  "Please refer to .cam_to_vio_test.log for details."
		fi
		exit 1
	fi
}

run(){
	if [ $cam_type = "dual" ];then
		echo "Display time will be doubled."
		echo cam0 > /sys/x2_iar/iar_test_attr
	fi

	if [ $if_show_config -eq 1 ];then
		show_config 0
	fi

	cmd="$VIO_APP_PATH/vio_test -I $interface_type \
		-v $IAR_VIO_CONFIG_PATH/$VIO_CONFIG \
		-c $CAMERA_CONFIG_PATH/$CAM_CONFIG \
		-i $cam_index \
		-r $run_time\
		-t $info_type \
		-l $loop \
		-s $stop \
		-p $start \
		-f $free \
		-g $get \
		-d $dbg \
		-S $status \
		-C $mipi_check \
		-P $process \
		-T $pym_time \
		-M $if_imx390 \
		-L $imx390_log \
		-R $press_test \
		-A $test_3a > .cam_to_vio_test.log"
	$cmd
	err_check "vio_test"
	if [ $cam_type = "dual" ];then
		echo "Displaying 0238."
		echo cam1 > /sys/x2_iar/iar_test_attr
		$cmd
		err_check "vio_test"
	fi
}

if [ $# -lt 4 ];then
	echo "Not enough options passed!" 1>&2
	usage
fi

while getopts "a:o:b:c:t:hi" opt; do
	case ${opt} in
	a )
		IAR_CONFIG=$OPTARG
	;;
	o )
		if [ $OPTARG != "hdmi" ] && [ $OPTARG != "lcd" ];then
			echo "Please select from \"hdmi\" or \"lcd\" for output." 1>&2
			usage
		else
			out_type=$OPTARG
		fi
	;;
	b )
		if [ $OPTARG != "x2dev" ] && [ $OPTARG != "j2dev" ];then
			echo "Please select from \"x2dev\" or \"j2dev\" for board type." 1>&2
			usage
		else
			board_type=$OPTARG
		fi
	;;
	c )
		if [ $OPTARG != "imx390" ] && [ $OPTARG != "dual" ];then
			echo "Please select from \"imx390\" or \"dual\" for camera type." 1>&2
			usage
		else
			cam_type=$OPTARG
		fi
	;;
	t )
		run_time=$OPTARG
	;;
	h )
		usage
	;;
	i )
		if_show_config=1
	;;
	\? )
		echo "Unknown option: $OPTARG" 1>&2
		usage
	;;
	: )
		echo "Invalid option: $OPTARG requires an argument" 1>&2
		usage
	;;
	esac
done
shift $((OPTIND -1))

if [ $run_time -lt 0 ];then
	echo "Run time must be greater than or equal to 0!"
	exit 1
fi

if [ $# -ne 0 ];then
	echo "Extra options detected, configuring."
	if [ $# -eq 15 ];then
		interface_type=$1
		VIO_CONFIG=$2
		CAM_CONFIG=$3
		cam_index=$4
		info_type=$5
		loop=$6
		stop=$7
		start=$8
		free=$9
		get=$10
		dbg=$11
		status=$12
		mipi_check=$13
		process=$14
		pym_time=$15
	elif [ $# -eq 7 ];then
		VIO_CONFIG=$1
		CAM_CONFIG=$2
		cam_index=$3
		if_imx390=$4
		imx390_log=$5
		press_test=$6
		test_3a=$7
	else
		echo "Options number $# does not match options for $cam_type camera."
		usage
	fi
else # no configs specified for vio_test
	DUAL_VIO_CONFIG="vio_onsemi_dual.json"
	IMX_VIO_CONFIG="vio_imx390_2L.json"
	CAM_CONFIG="hb_$board_type.json"

	if [ "$cam_type" = "imx390" ];then
		if [ "$board_type" = "x2dev" ];then
			imx390_cam_index=3
		fi
		if_imx390=1
		cam_index=$imx390_cam_index
		VIO_CONFIG=$IMX_VIO_CONFIG
	else
		VIO_CONFIG=$DUAL_VIO_CONFIG
	fi
fi

sed -i '/"iar"/{n;s/"enable":.*0/"enable":1/}' $IAR_VIO_CONFIG_PATH/$VIO_CONFIG

echo "Displaying Camera $cam_type on $out_type on board $board_type."
echo "Will be displaying the input from Camera $cam_type for $run_time seconds."
echo "Beginning Test."

if [ -z "$IAR_CONFIG" ];then
	if [ "$out_type" = "lcd" ];then
		echo "lcd" > /sys/x2_iar/iar_test_attr
		if [ $cam_type = "dual" ];then
			IAR_CONFIG="iar_lcd_dual_camera_0.json"
		else # cam_type == imx390
			IAR_CONFIG="iar_imx390_lcd.json"
		fi
	else # out_type = hdmi
		if [ "$cam_type" = "dual" ];then
			IAR_CONFIG="iar_xc9080_dual_0_hdmi.json"
		else # cam_type == imx390
			IAR_CONFIG="iar_imx390_hdmi.json"
		fi
	fi
fi

cp -f $IAR_VIO_CONFIG_PATH/$IAR_CONFIG $IAR_VIO_CONFIG_PATH/iar.json
err_check "cp"
run
err_check "vio_test"
echo "Camera to display test successful!"