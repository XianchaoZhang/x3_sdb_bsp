#!/bin/sh
if test "$1" == "ov10635"; then
	/app/bin/vio_test -I1 -v /etc/vio/vio_ov10635.json  -c /etc/cam/hb_j2dev.json -i2 -t2 -l0 -p1 -s1 -f1 -g1 -d1 -S0 -C1 -P0 -T20
elif test "$1" == "skcam01"; then
	/app/bin/vio_test -I1 -v /etc/vio/vio_sk.json  -c /etc/cam/hb_sk.json -i0 -t2 -l0 -p1 -s1 -f1 -g1 -d1 -S0 -C1 -P0 -T20
fi
