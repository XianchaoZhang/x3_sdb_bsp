#!/bin/sh
# entry script for diag test.
# by bo01.chen at 20190528.

# $@
# $? - 0-OK,!0-ERROR.

# script env.
SCRP_NAME=`basename $0`
THIS_PATH=`cd "$(dirname $0)"; pwd`
. ${THIS_PATH}/_env

# exec env init.
SexecEnv diag /bin/diag
SexecEnv diag_test ${THIS_PATH}/../bin/
# do exec.
SexecRun diag &
sleep 7s
SexecRun diag_test

if [ $? -ne 0 ];then
	echo "diag test fail!!!"
	exit -1
fi

# return.
Sreturn











