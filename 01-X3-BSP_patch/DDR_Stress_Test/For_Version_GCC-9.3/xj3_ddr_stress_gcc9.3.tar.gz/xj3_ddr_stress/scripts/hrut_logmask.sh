hrut_logmask s verbose
var1=`hrut_logmask g`
if [ $var1 = "verbose" ];then
	echo "set log verbose pass"
else 
	echo "set log verbose failed"
	exit 1
fi

hrut_logmask s debug
var2=`hrut_logmask g`
if [ $var2 = "debug" ];then
        echo "set log debug pass"
else
        echo "set log debug failed"
        exit 1
fi


hrut_logmask s info
var3=`hrut_logmask g`
if [ $var3 = "info" ];then
        echo "set log info pass"
else
        echo "set log info failed"
        exit 1
fi

hrut_logmask s warn
var4=`hrut_logmask g`
if [ $var4 = "warn" ];then
        echo "set log warn pass"
else
        echo "set log warn failed"
        exit 1
fi

hrut_logmask s error
var5=`hrut_logmask g`
if [ $var5 = "error" ];then
        echo "set log error pass"
else
        echo "set log error failed"
        exit 1
fi

