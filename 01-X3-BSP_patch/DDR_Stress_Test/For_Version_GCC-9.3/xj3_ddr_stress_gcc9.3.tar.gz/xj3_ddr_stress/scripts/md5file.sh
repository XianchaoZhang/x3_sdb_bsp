cd /tmp
touch 1
md5sum 1
if [ $? -ne 0 ];then
	echo "md5 file failed"
	exit 1
fi

touch 2
md5sum 2
if [ $? -ne 0 ];then
        echo "md5 file failed"
        exit 1
fi

touch 3
md5sum 3
if [ $? -ne 0 ];then
        echo "md5 file failed"
        exit 1
fi

rm 1
rm 2
rm 3
