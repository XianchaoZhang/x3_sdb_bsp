#!/bin/sh

if [ -d .mmc_test_tmp ];then
	rm -rf .mmc_test_tmp
fi

i=0
cur_pos=1
cur_pow=1

cus_blk_size=0
cus_par_size=0
cus_par_path=0
cus_cnt=0

blk_size=512
cnt=1
partition_size=15000
cur_num_p=`cat /proc/partitions | grep -i mmcblk0p | wc -l`
mmc_path=/dev/mmcblk0p$cur_num_p

while getopts "c:b:d:s:h" opt; do
	case ${opt} in
	c )
		cnt=$OPTARG
		cus_cnt=1
		;;
	b )
		blk_size=$OPTARG
		cus_blk_size=1
		;;
	d )
		if [ ! -e $OPTARG ];then
			echo "$OPTARG does not exist. Please Enter a valid partition!"
			exit 1
		else
			mmc_path=$OPTARG
			cus_par_path=1
		fi
		;;
	s )
		partition_size=$OPTARG
		cus_par_size=1
		;;
	h )
		echo "Usage: ./mmc_test.sh [-c block count] [-b blk_size(default 512)] [-d partition path] [-s partition size(Bytes)] [-h]"
		exit 0
		;;
	\? )
		echo "Usage: ./mmc_test.sh [-c block count] [-b blk_size(default 512)] [-d partition path] [-s partition size(Bytes)] [-h]" 1>&2
		exit 1
		;;
	: )
		echo "Invalid option: $OPTARG requires an argument" 1>&2
		exit 1
		;;
	esac
done
shift $((OPTIND -1))

if [ $cus_blk_size -eq 0 ]; then
	echo "Using Default Block size of 512 Bytes"
fi

if [ $cus_cnt -eq 0 ]; then
	echo "Using Default Block count of 1"
fi

if [ $cus_par_path -eq 0 ]; then
	echo "Using Default(last) mmc Partition, $mmc_path"
fi

if [ $cus_par_size -eq 0 ]; then
	echo "Using Default mmc Partition size of 15000 Bytes"
fi

mkdir .mmc_test_tmp
test_file_path=.mmc_test_tmp/input.test

echo Testing mmc r/w functions

blk_jmp=$(($blk_size*$i))
test_size=$(($blk_size*$cnt))

while [ $(($blk_jmp+$test_size)) -lt $partition_size ];
do
	echo -n Testing blk of size $test_size at $blk_jmp bytes away from start of $mmc_path...
	dd if=/dev/zero of=$test_file_path bs=$blk_size count=$cnt >& .mmc_test.log

	sync >& .mmc_test.log
	echo 3 > /proc/sys/vm/drop_caches >& .mmc_test.log

	cpy_path=.mmc_test_tmp/$i.test

	
	dd if=$test_file_path of=$mmc_path bs=$blk_size count=$cnt seek=$i >& .mmc_test.log
	dd if=$mmc_path of=$cpy_path bs=$blk_size count=$cnt skip=$i >& .mmc_test.log

	sync >& .mmc_test.log
	echo 3 > /proc/sys/vm/drop_caches >& .mmc_test.log

	diff $cpy_path $test_file_path

	if [ $? -ne 0 ];then
		echo "error:emmc test fail!!!"
		echo "Please see .mmc_test_tmp and .mmc_test.log for details."
		exit 1
	fi
	echo Success!

	if [ $cur_pos == 1 ];then
		cur_pos=2
	elif [ $cur_pos == 2 ];then
		cur_pos=5
	else #cur_pos=5
		cur_pos=1
		cur_pow=$(($cur_pow*10))
	fi
	i=$(($cur_pos*$cur_pow))
	blk_jmp=$(($blk_size*$i))
done
rm -rf .mmc_test_tmp/
echo Finished without error
rm .mmc_test.log
