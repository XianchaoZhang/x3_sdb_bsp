#!/bin/sh

##################################################
# read/write test
##################################################
size=65536
block=512
cnt=`expr $size / $block`
mtd_debug erase /dev/mtd0 0x0 $size
dd if=/dev/urandom of=flash_wr_pattern bs=$block count=$cnt
mtd_debug write /dev/mtd0 0x0 $size flash_wr_pattern
mtd_debug read /dev/mtd0 0x0 $size flash_rd_pattern

##################################################
# result check 
##################################################
result=`md5sum flash_*_pattern | awk '{print $1}'`
a=`echo $result | awk '{print $1}'`
b=`echo $result | awk '{print $2}'`
if [ "$a" != "$b" ];then
        echo "norflash test failed!"
        exit -1
fi
rm flash_*_pattern
