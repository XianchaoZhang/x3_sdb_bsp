#!/bin/sh

REGULATORS_PATH=/sys/class/regulator
CPU_PATH=/sys/devices/system/cpu
BPU_PATH=/sys/class/devfreq
BPU_ENABLE=/sys/devices/system/bpu/
TEMP=/sys/class/thermal/thermal_zone0/temp
CPU_NAME="VCC_CPU"
BPU_NAME="VCC_CNN"
CPU_REGULATOR=
BPU0_REGULATOR=
BPU1_REGULATOR=

cpu_freq=
cpu_policy=
cpu_governor=
cpu_boost=
bpu_freq=
bpu_freq=
bpu_gover=

bpu_over=0
cpu_over=0

helper(){
	echo
	echo "***************************************************************"
	echo "Usage :"
	echo "    b : test bpu overclock"
	echo "    c : test cpu overclock"
	echo "    h : helper"
	echo
	echo "    ./pmic-xj3-test.sh -b -c"
	echo "    ./pmic-xj3-test.sh -b"
	echo "    ./pmic-xj3-test.sh -c"
}

##############################################
#get_regulator : find regulator for expected
#$1 : regulator path in sysfs
#$2 : the regulator which you want to find
##############################################
get_regulator(){
	path=$1
	name=$2
	files=$(ls $path)
	for filename in $files
	do
		temp_name=`cat $path/$filename/name` 2>/dev/null
		if [ "$temp_name"x == "$name"x ]; then
			echo $filename
		fi
   	done
}


######################################
#get_cpu_env : set environment for test
#$1 : cpu number, cpu0,cpu1,cpu2,cpu3
######################################
get_cpu_env(){
	cpu=$1
	cpu_freq=`cat $CPU_PATH/$cpu/cpufreq/scaling_cur_freq`
	echo "cpu_freq : $cpu_freq"
	cpu_policy=`cat /sys/class/thermal/thermal_zone0/policy`
	echo "cpu_policy : $cpu_policy"
	cpu_governor=`cat /sys/devices/system/cpu/$cpu/cpufreq/scaling_governor`
	echo "cpu_governor : $cpu_governor"
	cpu_boost=`cat /sys/devices/system/cpu/cpufreq/boost`
	echo "cpu_boost : $cpu_boost"
}

######################################
#set_cpu_env : set environment for test
#$1 : cpu number, cpu0,cpu1,cpu2,cpu3
######################################
set_cpu_env(){
	cpu=$1
	echo user_space > /sys/class/thermal/thermal_zone0/policy
	echo userspace > /sys/devices/system/cpu/$cpu/cpufreq/scaling_governor
	echo 1 >   /sys/devices/system/cpu/cpufreq/boost
}

######################################
#save_cpu_env : recovery environment after test
#$1 : cpu number, cpu0,cpu1,cpu2,cpu3
######################################
save_cpu_env(){
	cpu=$1
	echo "cpu_freq : $cpu_freq"
	echo $cpu_freq > $CPU_PATH/$cpu/cpufreq/scaling_setspeed
	sleep 1
	echo "cpu_boost : $cpu_boost"
	echo $cpu_boost > /sys/devices/system/cpu/cpufreq/boost
	sleep 1
	echo "cpu_governor : $cpu_governor"
	echo $cpu_governor > /sys/devices/system/cpu/$cpu/cpufreq/scaling_governor
	sleep 1
	echo "cpu_policy : $cpu_policy"
	echo $cpu_policy > /sys/class/thermal/thermal_zone0/policy
	sleep 1
}

test_cpu_freq(){
	cpu=$1
	freq=$2
	vol=$3
	ret=0
	echo $freq > $CPU_PATH/$cpu/cpufreq/scaling_setspeed
	tmp_freq=`cat $CPU_PATH/$cpu/cpufreq/scaling_cur_freq`
	temp_vol=`cat $REGULATORS_PATH/$CPU_REGULATOR/microvolts`
	echo "current voltage is $temp_vol for freq $tmp_freq"
	if [ "$temp_vol"x != "$vol"x ]; then
		echo "current voltage is not $vol, error"
		save_cpu_env $cpu
		echo $cur_freq > $CPU_PATH/$cpu/cpufreq/scaling_setspeed
		ret=1
		return $ret
	fi
	return $ret
}

################################################
#test_cpu : test cpu volatge is OK
#$1 : cpu number, such as cpu0, cpu1 and so on
################################################
test_cpu(){
	cpu=$1
	cat $TEMP
	echo "test $cpu start"
	get_cpu_env $cpu
	set_cpu_env $cpu
	CPU_REGULATOR="$(get_regulator $REGULATORS_PATH $CPU_NAME)"
    echo "cpu regulator : $CPU_REGULATOR"
	test_cpu_freq $cpu 800000 800000
	ret=$?
	echo "result : $ret"
	if [ $ret -ne 0 ];then
		echo "test $cpu freq 800000 fail"
		return $ret
	fi
	sleep 2
	if [ ${cpu_over} -eq 1 ];then
		test_cpu_freq $cpu 1500000 1000000
		ret=$?
		echo "result : $ret"
		if [ $ret -ne 0 ];then
			echo "test $cpu freq 1500000 fail"
			return $ret
		fi
		sleep 2
		test_cpu_freq $cpu 800000 800000
		ret=$?
		echo "result : $ret"
		if [ $ret -ne 0 ];then
			echo "test $cpu freq 800000 again fail"
			return $ret
		fi
		sleep 2
	fi
	echo "test $cpu done"
	save_cpu_env $cpu
	echo "test $cpu done"
	ret=0
	return $ret
}

get_bpu_env(){
	bpu=$1
	bpu_gover=`cat $BPU_PATH/devfreq$bpu/governor`
	echo "bpu$bpu current governor : $bpu_gover"
	bpu_freq=`cat $BPU_PATH/devfreq$bpu/cur_freq`
	echo "bpu$bpu current freq : $bpu_freq"
	bpu_power=`cat $BPU_ENABLE/bpu$bpu/power_enable`
	echo "bpu$bpu current power : $bpu_power"
}


set_bpu_env(){
	bpu=$1
	echo $bpu_freq > $BPU_PATH/devfreq$bpu/userspace/set_freq
	sleep 1
	echo $bpu_gover > $BPU_PATH/devfreq$bpu/governor
	sleep 1
	echo $bpu_power > $BPU_ENABLE/bpu$bpu/power_enable
	sleep 1
}

test_bpu_freq(){
	bpu=$1
	freq=$2
	vol=$3
	ret=0
	echo $freq > $BPU_PATH/devfreq$bpu/userspace/set_freq
	temp_freq=`cat $BPU_PATH/devfreq$bpu/cur_freq`
	echo "bpu current frequence is $cur_freq"
	temp_vol=`cat $REGULATORS_PATH/$BPU_REGULATOR/microvolts`
	echo "current voltage is $temp_vol for freq $temp_freq"
	if [ "$temp_vol"x != "$vol"x ]; then
		echo "current voltage is not $vol, error"
		set_bpu_env $bpu
		ret=1
		return $ret
	fi
	return $ret
}

################################
#test_bpu : test bpu
#$1 : bpu number, 0,1
################################
test_bpu(){
	bpu=$1
	echo "test bpu$bpu start"
	BPU_REGULATOR="$(get_regulator $REGULATORS_PATH $BPU_NAME$bpu)"
    echo "bpu regulator : $BPU_REGULATOR"
	get_bpu_env $bpu
	echo "bpu current frequence : $bpu_freq, governor : $bpu_gover, power : $bpu_power"
	echo 1 > $BPU_ENABLE/bpu$bpu/power_enable
	echo userspace > $BPU_PATH/devfreq$bpu/governor
	test_bpu_freq $bpu 1000000000 800000
	ret=$?
	echo "result : $ret"
	if [ $ret -ne 0 ];then
		echo "test bpu$bpu freq 1000000000 fail"
		return $ret
	fi
	sleep 2
	if [ ${bpu_over} -eq 1 ];then
		test_bpu_freq $bpu 1200000000 1000000
		ret=$?
		echo "result : $ret"
		if [ $ret -ne 0 ];then
			echo "test bpu$bpu freq 1200000000 fail"
			return $ret
		fi
		sleep 2
		test_bpu_freq $bpu 1000000000 800000
		ret=$?
		echo "result : $ret"
		if [ $ret -ne 0 ];then
			echo "test bpu$bpu freq 1000000000 again fail"
			return $ret
		fi
		sleep 2
	fi
	echo "bpu$bpu test freq done"
	ret=0
	set_bpu_env $bpu
	return $ret
}
################################
#all_test : test cpu0,bpu0,bpu1
################################
all_test(){
	test_cpu cpu0
	rc=$?
	if [ $rc -ne 0 ];then
		return 1
	fi
	# test_bpu 0
	# rc=$?
	# if [ $rc -ne 0 ];then
	# 	return 2
	# fi
	# test_bpu 1
	# rc=$?
	# if [ $rc -ne 0 ];then
	# 	return 3
	# fi
	echo "**************************"
}

##################################
#main
##################################

while getopts "bc" opt; do
	  case $opt in
		b) bpu_over=1
			;;
		c) cpu_over=1
			;;
		h) helper
			exit
			;;
		\?)
			echo "Invalid option" >&2
			helper
			;;
	esac
done

all_test
rc=$?
echo "test result : $rc"
if [ $rc -eq 0 ];then
	echo "test all success"
	exit 0
elif [ $rc -eq 1 ];then
	echo "CPU test fail"
	exit 1
elif [ $rc -eq 2 ];then
	echo "BPU0 test fail"
	exit 1
elif [ $rc -eq 3 ];then
	echo "BPU1 test fail"
	exit 1
else
	echo "fail code : $rc"
	exit 1
fi
echo "**************************"
