knl_version=`uname -r`
insmod /lib/modules/${knl_version}/elppdu.ko
insmod /lib/modules/${knl_version}/elpmem.ko
insmod /lib/modules/${knl_version}/elpspacc.ko
insmod /lib/modules/${knl_version}/elpspaccdev.ko
insmod /lib/modules/${knl_version}/elpspacccrypto.ko
insmod /lib/modules/${knl_version}/elprsa.ko
insmod /lib/modules/${knl_version}/elpclp800.ko


count=0
cd /app/scripts/secip_test

sh 0_test_proc_crypto.sh
if [ ! $? -eq 0 ];then
	echo "0_test_proc_crypto failed."
	count=`expr $count + 1`
fi

sh 1_test_crypto_drv.sh
if [ ! $? -eq 0 ];then
	echo "1_test_crypto_drv failed."
	count=`expr $count + 1`
fi

sh 2_test_secip_api.sh
if [ ! $? -eq 0 ];then
	echo "2_test_secip_api failed."
	count=`expr $count + 1`
fi

sh 3_test_pka_function.sh
if [ ! $? -eq 0 ];then
	echo "3_test_pka_function failed."
	count=`expr $count + 1`
fi

sh 4_test_trng_reset.sh
if [ ! $? -eq 0 ];then
	echo "4_test_trng_reset failed."
	count=`expr $count + 1`
fi

if [ ! $count -eq 0 ];then
	echo "secip test failed."
	exit 1
fi

echo "secip test passed."


rmmod /lib/modules/${knl_version}/elprsa.ko
rmmod /lib/modules/${knl_version}/elpclp800.ko
rmmod /lib/modules/${knl_version}/elpspacccrypto.ko
rmmod /lib/modules/${knl_version}/elpspaccdev.ko
rmmod /lib/modules/${knl_version}/elpspacc.ko
rmmod /lib/modules/${knl_version}/elpmem.ko
rmmod /lib/modules/${knl_version}/elppdu.ko
