echo "secip: test crypto driver with libkcapi app"

failed_cnt=0
keyfile="keybox"

for cipher in "spacc-ecb(aes)" "spacc-cbc(aes)" "spacc-ctr(aes)"
do
	echo -n "$cipher    "

	fname=test.1MB.data
	dd if=/dev/urandom of=$fname bs=1024 count=1024 &> /dev/null
	iv=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom`
	kcapi-enc -q --pbkdfiter 100 -p "passwd" -s "123" -e -c "$cipher" --iv "$iv" -i ${fname} -o ${fname}.enc --nounpad
	kcapi-enc -q --pbkdfiter 100 -p "passwd" -s "123" -d -c "$cipher" --iv "$iv" -i ${fname}.enc -o ${fname}.dec --nounpad
	cmp ${fname} ${fname}.dec

	if [ $? -eq 0 ];then
		echo "passed"
	else
		echo "failed"
		failed_cnt=`expr $failed_cnt + 1`
	fi
done

for cipher in "spacc-ecb(des)" "spacc-cbc(des)"
do
	echo -n "$cipher    "

	fname=test.1MB.data
	dd if=/dev/urandom of=$fname bs=1024 count=1024 &> /dev/null
	iv=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom`
	key=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom | cut -c -8`
	echo -n "$key" > $keyfile

	exec 10<$keyfile; kcapi-enc --keyfd 10 -e -c $cipher --iv "$iv" -i ${fname} -o ${fname}.enc --nounpad
	exec 10<$keyfile; kcapi-enc --keyfd 10 -d -c $cipher --iv "$iv" -i ${fname}.enc -o ${fname}.dec --nounpad

	cmp ${fname} ${fname}.dec

	if [ $? -eq 0 ];then
		echo "passed"
	else
		echo "failed"
		failed_cnt=`expr $failed_cnt + 1`
	fi
done

for cipher in "spacc-ecb(des3_ede)" "spacc-cbc(des3_ede)"
do
        echo -n "$cipher    "

        fname=test.1MB.data
        dd if=/dev/urandom of=$fname bs=1024 count=1024 &> /dev/null
        iv=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom`
        key=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom | cut -c -24`
        echo -n "$key" > $keyfile

        exec 10<$keyfile; kcapi-enc --keyfd 10 -e -c $cipher --iv "$iv" -i ${fname} -o ${fname}.enc --nounpad
        exec 10<$keyfile; kcapi-enc --keyfd 10 -d -c $cipher --iv "$iv" -i ${fname}.enc -o ${fname}.dec --nounpad

        cmp ${fname} ${fname}.dec

        if [ $? -eq 0 ];then
			echo "passed"
        else
			echo "failed"
			failed_cnt=`expr $failed_cnt + 1`
        fi
done

echo "test hash sum ..."
txtname=rfc4868.rfc5754.txt
fname=16K.txt
dd if=$txtname of=$fname bs=1 count=16384 &> /dev/null

#for test in "md5 e8ada8148235bbaf42abb2a9ff05098b" \
#	"sha1 94307a0648c68b279a121efecce390c30a2f66a5" \
#	"sha256 f7093d86a7de4553d2980f3330b0eed4e8d999604db4bb6c9aca90306ccaa6fe"\
#	"sha512 c75d8a3b5e21f2285999eb52c30ab42a54982961dad89d8553708b29e26fbc8d697a129654511d5d74664eba2a29035851eb83241f2fb056a96e8381b2e0ec65"
for test in "md5 8e1ffe11576f475a953920641937e497" \
	"sha1 3fdff60f64fc4e247b290a6b2344820cefec282d" \
	"sha256 5b05eb8509e4f6b22b990ee759368db1cc229a62274523486ee065f7a729e545"\
	"sha512 8e003690a8dfbe2dc4229f4f8a2f2d01730d887ef3ba4b9efbcda9eb48f2e9c4c322b8f2b35fff2563fcdd5bdb8b000bfd807dbd6fe8f19928011a632dfed64c"
do
	hash=`echo $test | cut -d' ' -f 1`
	sum=`echo $test | cut -d' ' -f 2`

#	echo -n "${hash}sum    "

#	result=`${hash}sum $fname`
	result=`kcapi-dgst -c ${hash} -i $fname --hex`
	result=`echo $result | cut -d' ' -f 1`
	echo "$result"

	if [ "$result" == "$sum" ];then
		echo "passed"
	else
		echo "failed"
		failed_cnt=`expr $failed_cnt + 1`
	fi
done

echo
echo "test hmac ..."
txtname=rfc4868.rfc5754.txt
fname=16K.txt
echo 123 > $keyfile
dd if=$txtname of=$fname bs=1 count=16384 &> /dev/null
#for test in "sha1 7287dfee95caceb38e593945192032d53d2ccab5" \
#	"sha256 8453c1433b11d865787adc2c713169c1ea1ccda20d403ce1162102e8a63f740f"\
#	"sha512 f7d1a2eeb80e92a2f2a58ecddb27b88d1d34c4e0f3564da9f3d2fd81db5daece31ffb9ee17e90b05b736f41b5198554c7d06d497db5fd5bc967189060a2b9b43"
#for test in "sha1 ad348bcee2db10e3165ca83fe31c954c657fe477" \
#	"sha256 3ed2fedcb5b01da8c8c1997af6d070a8a5b8b4e643e3882ec8dc7d87500a3f15"\
#	"sha512 6cedd68c3fe8388d9f1fba6fc0f5cda531fa55874ca68c63cd5fb2bcb7807869754bce5af1ec0c78fb71da1ed6785c5d915fc7fd5667f0329e88255a5042c240"
for test in "sha1 daf74ec157bd7648bfd128e16dabb8e6b92c042a" \
	"sha256 57af3dc9ad2cb7c9fb8e31054997c4e3bb0276e4bf6e25ddd8a94b458eb7ae33"\
	"sha512 da0557793895e2c7404ce0ea375e089ca3a0436ec8bea3403f5c6dfcb3e7da23a146b814ba9ac12ebc9f20bcbc2d04cc0dae0348c15a94a5bdaee57bf19f0a8a"
do
	hash=`echo $test | cut -d' ' -f 1`
	hmac=`echo $test | cut -d' ' -f 2`

	echo -n  "${hash}hmac    "

	exec 10<$keyfile
	result=`kcapi-dgst --keyfd 10 -c "hmac(${hash})" --hex < $fname`
#	result=`${hash}hmac $fname -K "123"`
	result=`echo $result | cut -d' ' -f 1`

	if [ "$result" == "$hmac" ];then
		echo "passed"
	else
		echo "failed"
		failed_cnt=`expr $failed_cnt + 1`
	fi
done

echo
echo "HW hash for file equal and larger than 64KB is not standard due to HW limitation."
echo "So we only check the hash length generated."


fname=test.10MB.data
dd if=/dev/urandom of=$fname bs=1024 count=10240 &> /dev/null
for test in "sha1 7287dfee95caceb38e593945192032d53d2ccab5" \
	"sha256 8453c1433b11d865787adc2c713169c1ea1ccda20d403ce1162102e8a63f740f"\
	"sha512 f7d1a2eeb80e92a2f2a58ecddb27b88d1d34c4e0f3564da9f3d2fd81db5daece31ffb9ee17e90b05b736f41b5198554c7d06d497db5fd5bc967189060a2b9b43"
do
	hash=`echo $test | cut -d' ' -f 1`
	sum=`echo $test | cut -d' ' -f 2`

#	sum_result=`${hash}sum $fname`
	sum_result=`kcapi-dgst -c ${hash} -i $fname --hex`
	sum_result=`echo $sum_result | cut -d' ' -f 1`

	len_expected=$(echo -n $sum |  wc -m)
	len_result=$(echo -n $sum_result |  wc -m)
	echo -n "$hash  $len_expected "
	if [ $len_expected -eq $len_result ];then
		echo "passed"
	else
		echo "failed"
		failed_cnt=`expr $failed_cnt + 1`
	fi

	exec 10<$keyfile
	hmac_result=`kcapi-dgst --keyfd 10 -c "hmac(${hash})" --hex < $fname`
#	hmac_result=`${hash}hmac -K "123" $fname`
	hmac_result=`echo $hmac_result | cut -d' ' -f 1`

	len_result=$(echo -n $hmac_result |  wc -m)

	echo -n "hmac($hash)  $len_expected "
	if [ $len_expected -eq $len_result ];then
		echo "passed"
	else
		echo "failed"
		failed_cnt=`expr $failed_cnt + 1`
	fi
done

rm -f $fname

if [ $failed_cnt -eq 0 ];then
	echo "all passed"
else
	echo "failed $failed_cnt cases"
	exit 255
fi

#rmmod elpspacccrypto
