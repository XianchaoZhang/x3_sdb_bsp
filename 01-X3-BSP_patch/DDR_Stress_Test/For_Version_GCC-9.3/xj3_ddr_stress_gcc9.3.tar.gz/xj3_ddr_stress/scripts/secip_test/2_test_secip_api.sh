echo "test secure ip API"

/app/bin/hbsec_crypto_test

ret=$?
if [ ! $ret -eq 0 ];then
	echo "hbsec_crypto_test failed"
	exit $ret
fi
echo "hbsec crypto API basic cipher and hash test passed"

/app/bin/hbsec_crypto_test_mt2 8
ret=$?
if [ ! $ret -eq 0 ];then
	echo "hbsec_crypto_test_mt2 failed"
	exit $ret
fi
echo "hbsec crypto API multipe threads cipher and hash test passed"

rm -f mt_data.bin
rm -f mt_hash.bin
