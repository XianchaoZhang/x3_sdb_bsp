export OPENSSL_CONF=$PWD/rsa_engine.cnf

# A generates private key `priv_key.pem`
openssl genrsa -out priv_key.pem 2048

# A extracts the public key `pub_key.pem` and sends it to B
openssl rsa -pubout -in priv_key.pem -out pub_key.pem

# B encrypts a message and sends `encrypted_with_pub_key` to A
openssl rsautl -encrypt -in cleartext -out encrypted_with_pub_key -inkey pub_key.pem -pubin

# A decrypts B's message
openssl rsautl -decrypt -in encrypted_with_pub_key -inkey priv_key.pem > cleartext.dec

cmp cleartext.dec cleartext

if [ ! $? -eq 0 ];then
	exit 255
fi
