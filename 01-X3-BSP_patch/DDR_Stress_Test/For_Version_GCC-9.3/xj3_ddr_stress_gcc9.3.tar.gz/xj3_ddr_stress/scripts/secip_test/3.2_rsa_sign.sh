export OPENSSL_CONF=$PWD/rsa_engine.cnf

#gen private key with 2048bit len
openssl genrsa -out private.key 2048


# gen public key by private.key
openssl rsa -in private.key -pubout > public.key

# gen a message
echo "A private message" > message

# mapping message to hash key by sha256
openssl dgst -sha256 -out hash.key message

# create a signature by private key
cat hash.key | openssl rsautl -inkey private.key -sign  > signature

# verify signature by public key
openssl rsautl -inkey public.key -pubin -in signature > hash2.key

md5sum hash.key hash2.key
diff -s hash.key hash2.key

if [ ! $? -eq 0 ];then
	exit 255
fi

rm hash.key hash2.key message private.key  public.key signature
