i=10
while [ $i != 0 ]
do
	echo random >  /sys/devices/platform/clp800/reseed_action
	seed_len=`cat   /sys/devices/platform/clp800/seed | wc -m`

	echo 16 > /sys/devices/platform/clp800/output_len
	cat /sys/devices/platform/clp800/random
	len_16=`cat /sys/devices/platform/clp800/random | wc -m`
	echo 32 > /sys/devices/platform/clp800/output_len
	cat /sys/devices/platform/clp800/random
	len_32=`cat /sys/devices/platform/clp800/random | wc -m`

	if [ ! $seed_len -eq 65 ];then
		echo "trng failed with seed_len:$seed_len"
		exit 255
	fi

	if [ ! $len_16 -eq 33 ];then
		echo "trng failed with 16B output len:$seed_len"
		exit 255
	fi

	if [ ! $len_32 -eq 65 ];then
		echo "trng failed with 32B output len:$seed_len"
		exit 255
	fi

	i=$(($i-1))
done

echo "trng test passed"
