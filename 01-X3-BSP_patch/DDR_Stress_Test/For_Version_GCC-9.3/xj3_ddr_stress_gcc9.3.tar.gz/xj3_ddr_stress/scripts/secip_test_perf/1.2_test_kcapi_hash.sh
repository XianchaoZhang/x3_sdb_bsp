echo "secip: test crypto driver with libkcapi app"
echo "insmod /lib/modules/elpspacccrypto.ko"
insmod /lib/modules/elpspacccrypto.ko

echo 123 > hmac_keyfile
exec 10<hmac_keyfile
#$1: data_size, $2:hash name $3:hash/hmac
function run_hash
{
	blk_sz=4096
	total_sz_MB=100
	data_sz=$1

	if [ $data_sz -lt 1048577 ]; then
		total_sz_MB=10
	fi

	total_sz=`expr 1048576 \* $total_sz_MB`

	hash=$2
	cnt=`expr $data_sz / $blk_sz`
	fname=test.${data_sz}.data
	dd if=/dev/urandom of=$fname bs=$blk_sz count=$cnt &> /dev/null

	iter_cnt=`expr $total_sz / $data_sz`

	if [ "$3" == "hash" ];then
		cmd='kcapi-dgst -c ${hash} -i $fname --hex -o hash.output'
	elif [ "$3" == "hmac" ];then
		cmd='kcapi-dgst --keyfd 10 -c "hmac(${hash})" -i $fname --hex -o hmac.output'
	fi

	time_ms_before=$(($(date +%s%3N)))

	for i in `seq 1 1 $iter_cnt`;
	do
		eval $cmd
	done

	time_ms_after=$(($(date +%s%3N)))

	time_diff=`expr $time_ms_after - $time_ms_before`

	speed=`expr $total_sz_MB \* 1000000 / $time_diff`

	printf "%s %s speed with size:%-12d is %dKB/s\n" \
			$hash $3 $data_sz $speed

}

for hash in "sha1" "sha256" "sha512"
do
	echo 
	echo "test $hash"
	echo
	for size in 4096 16384  65536 1048576 10485760 104857600
	do
		run_hash $size $hash "hash"
		run_hash $size $hash "hmac"
	done

done

