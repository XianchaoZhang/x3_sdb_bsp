echo "secip: test crypto API performance"


#$1: data_size, $2:hash name, $3 keylen, $4 ivlen
function run_hash
{
	blk_sz=4096
	total_sz_MB=100
	data_sz=$1

	if [ $data_sz -lt 1048577 ]; then
		total_sz_MB=10
	fi

	total_sz=`expr 1048576 \* $total_sz_MB`

	hash=$2
	keylen=$3
	ivlen=$4
	cnt=`expr $data_sz / $blk_sz`
	fname=test.${data_sz}.data
	dd if=/dev/urandom of=$fname bs=$blk_sz count=$cnt &> /dev/null

	iv=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom | cut -c -${ivlen}`
	key=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom | cut -c -${keylen}`
	echo -n "$key" > key.fd

	iter_cnt=`expr $total_sz / $data_sz`

	time_ms_before=$(($(date +%s%3N)))

	for i in `seq 1 1 $iter_cnt`;
	do
		/app/bin/hbsec_crypto_file -i ${fname} -o ${fname}.hash  -a $hash  --keyfile key.fd -k $keylen &>/dev/null
		cat ${fname}.hash
	done

	time_ms_after=$(($(date +%s%3N)))

	time_diff=`expr $time_ms_after - $time_ms_before`

	speed=`expr $total_sz_MB \* 1000000 / $time_diff`

	printf "%-12s speed with size:%-12d keylen:%-2d is %-8dKB/s\n" \
			$hash $data_sz $keylen $speed

}


echo 
echo "test $hash"
echo
for size in 4096 16384  65536 1048576 10485760 104857600
do
	run_hash $size "sha1" 			0
	run_hash $size "hmac(sha1)" 	20
	run_hash $size "sha256" 		0
	run_hash $size "hmac(sha256)" 	32
	run_hash $size "sha512" 		0
	run_hash $size "hmac(sha512)" 	64
done

