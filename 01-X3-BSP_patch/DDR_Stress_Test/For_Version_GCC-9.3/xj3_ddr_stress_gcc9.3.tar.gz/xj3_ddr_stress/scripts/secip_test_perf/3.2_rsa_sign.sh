export OPENSSL_CONF=$PWD/rsa_engine.cnf

#gen private key with 2048bit len
openssl genrsa -out private.key 2048

# gen public key by private.key
openssl rsa -in private.key -pubout > public.key

# gen a message
echo "A private message" > message

# mapping message to hash key by sha256
openssl dgst -sha256 -out hash.key message

time_ms_before=$(($(date +%s%3N))) 
echo "before: $time_ms_before"

NUM=100
if [ ! $1 == "" ];then
	NUM=$1
fi

for i in `seq 1 1 $NUM`;
do
# create a signature by private key
cat hash.key | openssl rsautl -inkey private.key -sign  > signature

# verify signature by public key
openssl rsautl -inkey public.key -pubin -in signature > hash2.key
done

time_ms_after=$(($(date +%s%3N))) 

time_diff=`expr $time_ms_after - $time_ms_before`
printf "%d times rsa signature takes %d ms\n" $NUM $time_diff

md5sum hash.key hash2.key
diff -s hash.key hash2.key

if [ ! $? -eq 0 ];then
	exit 255
fi

rm hash.key hash2.key message private.key  public.key signature
