#!/bin/sh

cd /app/sleep_pack
./test.sh
var=$(echo $?)
if [ $var -ne 0 ];then
        echo "error:enter sleep fail!!!"
        exit 1
fi

exit 0
