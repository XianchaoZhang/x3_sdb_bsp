#!/bin/sh

cnt=0
sensors=`ls /sys/class/hwmon`
cd /sys/class/hwmon
for dir in ${sensors}
do
        temp_name=`cat ${dir}/name`
        temp_val=`cat ${dir}/temp1_input`
        if [ $temp_val -lt 10000 -o $temp_val -gt 100000 ];then
                echo "ts $temp_name temp value $temp_val error"
                exit 1
        fi
        echo "ts $temp_name temp value $temp_val"
        cnt=`expr $cnt + 1`
done

boardname=`cat /sys/class/socinfo/board_name`
echo $boardname | grep "cvb"
if [ $? -eq 0 -a ! $cnt -eq 4 ];then
        echo "sensor number $cnt error on $boardname "
        exit 1
fi


echo $boardname | grep "dvb"
if [ $? -eq 0 -a ! $cnt -ge 2 ];then
        echo "sensor number $cnt error on $boardname "
        exit 1
fi

echo $boardname | grep "sdb"
if [ $? -eq 0 -a ! $cnt -eq 1 ];then
        echo "sensor number $cnt error on $boardname "
        exit 1
fi

echo "$0 pass"
exit 0

