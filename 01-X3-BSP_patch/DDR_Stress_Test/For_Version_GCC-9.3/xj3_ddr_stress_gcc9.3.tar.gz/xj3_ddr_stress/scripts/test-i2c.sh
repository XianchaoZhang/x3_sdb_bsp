ret=0
result=0
echo "test read thermal by i2c start"
echo "******************************"
for i in `seq 10`
do
	echo "test thermal : $i"
	cat /sys/class/hwmon/hwmon1/temp1_input
	ret=$?
	echo "ret : $ret"
	result=$(($result + $ret))
	sleep 2s
done
echo "******************************"
echo "test read thermal by i2c done"
echo "test result : $result"
if [ $result -eq 0 ];then
	echo "test OK"
else
	echo "test FAIL"
fi
echo "******************************"

