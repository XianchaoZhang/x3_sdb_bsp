#!/bin/sh

IAR_CONFIG_PATH="/etc/vio/"
VIO_APP_PATH="/app/bin/"
CAMERA_CONFIG_PATH="/etc/cam/"

$VIO_APP_PATH/vio_test -I1 -v $IAR_CONFIG_PATH/vio_onsemi0230.json -c $CAMERA_CONFIG_PATH/hb_x2dev.json -i0 -t2 -l0 -p1 -s1 -f1 -g1 -d1 -S0 -C1 -P0 -T20
