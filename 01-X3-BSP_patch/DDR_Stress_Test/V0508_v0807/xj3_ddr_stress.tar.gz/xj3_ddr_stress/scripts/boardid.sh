var=`hrut_boardid g`

var1=`hrut_boardid c`
if [ x"$?" = x"0" ];then
    echo "clear boardid pass"
else
    echo "clear boardid error"
    exit 1
fi
echo 

hrut_boardid s $var
var2=`hrut_boardid g`
if [ $var2 = $var ];then
    echo "set boardid $var pass"
else
    echo "set boardid $var error"
    exit 1
fi
