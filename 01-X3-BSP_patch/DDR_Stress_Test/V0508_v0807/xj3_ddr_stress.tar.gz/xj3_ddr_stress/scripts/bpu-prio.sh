export BMEM_CACHEABLE=true
export LD_LIBRARY_PATH=/app/libbpu/hbdk3
export export BPLAT_CORELIMIT=1
OUTPUT_0_0=/userdata/model-p0000_00/
OUTPUT_0_1=/userdata/model-p0000_01/
OUTPUT_1_0=/userdata/model-p0000_10/
OUTPUT_1_1=/userdata/model-p0000_11/
HBM_FILE=/app/libbpu/HBDK3_MODEL_P0000/gen_P0000_MobileNetV1_1x224x224x3.hbm
SRC_FILE=/app/libbpu/HBDK3_MODEL_P0000/input_0_feature_1x224x224x3_ddr_native.bin
MODEL_NAME=P0000_MobileNetV1_1x224x224x3
if [ ! -d $OUTPUT_0_0 ];then
    mkdir $OUTPUT_0_0
else
    rm $OUTPUT_0_0 -r
    mkdir $OUTPUT_0_0
fi
if [ ! -d $OUTPUT_0_1 ];then
    mkdir $OUTPUT_0_1
else
    rm $OUTPUT_0_1 -r
    mkdir $OUTPUT_0_1
fi
if [ ! -d $OUTPUT_1_0 ];then
    mkdir $OUTPUT_1_0
else
    rm $OUTPUT_1_0 -r
    mkdir $OUTPUT_1_0
fi
if [ ! -d $OUTPUT_1_1 ];then
    mkdir $OUTPUT_1_1
else
    rm $OUTPUT_1_1 -r
    mkdir $OUTPUT_1_1
fi

/app/bin/tc_hbdk3 -f $HBM_FILE -i $SRC_FILE -n $MODEL_NAME -o $OUTPUT_0_0,$OUTPUT_0_1,$OUTPUT_1_0,$OUTPUT_1_1 -g 0 -c 200000 -k 0x10004 &
/app/bin/tc_hbdk3 -f $HBM_FILE -i $SRC_FILE -n $MODEL_NAME -o $OUTPUT_0_0,$OUTPUT_0_1,$OUTPUT_1_0,$OUTPUT_1_1 -g 0 -c 200000 &
/app/bin/tc_hbdk3 -f $HBM_FILE -i $SRC_FILE -n $MODEL_NAME -o $OUTPUT_0_0,$OUTPUT_0_1,$OUTPUT_1_0,$OUTPUT_1_1 -g 0 -c 200000 &
/app/bin/tc_hbdk3 -f $HBM_FILE -i $SRC_FILE -n $MODEL_NAME -o $OUTPUT_0_0,$OUTPUT_0_1,$OUTPUT_1_0,$OUTPUT_1_1 -g 0 -c 200000 &

