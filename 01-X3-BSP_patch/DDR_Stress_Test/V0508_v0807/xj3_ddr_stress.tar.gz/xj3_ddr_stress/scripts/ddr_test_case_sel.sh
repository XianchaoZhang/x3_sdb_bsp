#!/bin/sh
# CAUTION: Upon using memtester, when specifying pysical address, the maximum apce allocated can be no larger than 200kB
#          without specifying physical address, the maximum space allocated can be no larger than 1MB
#          for the fastest execution of this test script.

if [ -f .ddr_test.log ]; then
	rm .ddr_test.log
fi

test_cases="-t ran_val -t xor_cmp -t sub_cmp -t mul_cmp -t div_cmp -t or_cmp -t and_cmp -t seq_inc"
start_addr=0x05877000
end_addr=0x3ffff000
addr_mask=0x1000
addr_base=1
cus_end=0
cus_start=0
cus_test=0
while getopts "s:e:t:h" opt; do
	case ${opt} in
	e )
		end_addr=$OPTARG
		cus_end=1
		;;
	s )
		start_addr=$OPTARG
		cus_start=1
		;;
	t )
		test_cases="$test_cases -t $OPTARG"
		cus_test=1
		;;
	h )
		echo "Usage: ./ddr_test_case_sel.sh [-s start address(default 0x05877000)] [-t test cases] [-e end address(default 0x3ffff000)] [-h]"
		echo "Test Cases:"
		echo "    \"all\"    : run all the test cases below"
		echo "    \"ran_val\": random value"
		echo "    \"xor_cmp\": xor comparison"
		echo "    \"sub_cmp\": substract comparison"
		echo "    \"mul_cmp\": multiplication comparison"
		echo "    \"div_cmp\": division comparison"
		echo "    \"or_cmp\" : or comparison"
		echo "    \"and_cmp\": and comparison"
		echo "    \"seq_inc\": sequential increment"
		echo "    \"sld_bit\": solid bits"
		echo "    \"blk_seq\": block sequential"
		echo "    \"chk_brd\": checkerboard"
		echo "    \"bit_spr\": bit spread"
		echo "    \"bit_flp\": bit flip"
		echo "    \"wlk_one\": walking ones"
		echo "    \"wlk_zro\": walking zeroes"
		exit 0
		;;
	\? )
		echo "Usage: ./ddr_test_case_sel.sh [-s start address(default 0x05877000)] [-t test cases] [-e end address(default 0x3ffff000)] [-h]"
		exit 1
		;;
	: )
		echo "Invalid option: $OPTARG requires an argument" 1>&2
		exit 1
		;;
	esac
done
shift $((OPTIND -1))

if [ $cus_start -eq 0 ]; then
	echo "Using Default start address of 0x05877000"
fi

if [ $cus_end -eq 0 ]; then
	echo "Using Default end address of 0x3ffff000"
fi

if [ $cus_test -eq 0 ]; then
	echo "Using Default test cases: $test_cases"
fi

while [ $(($start_addr+0x32000)) -lt $(($end_addr)) ];
do
	cur_addr=`printf '%x' $start_addr`
	echo -n "Testing address $cur_addr..."
	/app/bin/memtester_case_sel $test_cases -p $cur_addr 200k 1 >& .ddr_test.log
	if [ $? -ne 0 ]; then
		echo "ddr test Failed!"
		echo "Please see .ddr_test.log for details."
		exit 1
	fi
	echo "Success!"
	if [ $addr_base == 1 ];then
		addr_base=2
	elif [ $addr_base == 2 ];then
		addr_base=5
	else #addr_base=5
		addr_base=1
		addr_mask=$(($addr_mask<<4))
	fi
	start_addr=$(($start_addr+$addr_base*$addr_mask))
done
rm .ddr_test.log
echo "All Tests Done!"