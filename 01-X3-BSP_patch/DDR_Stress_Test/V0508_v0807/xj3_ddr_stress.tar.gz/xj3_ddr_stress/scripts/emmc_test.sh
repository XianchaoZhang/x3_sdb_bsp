#!/bin/sh

# test script for dev: emmc.
# use tool: iozone.

# $1 - emmc test ko path.
# $? - 0-OK,!0-ERROR.

# get test module path.
if [ -z "$1" ]; then
    EMMC_KOP=/lib/mmc_test.ko
else
    EMMC_KOP=$1
fi
EMMC_KO=`basename ${EMMC_KOP} .ko`

# check test env.
KoDone=`lsmod |awk '{print $1}' |grep -w ${EMMC_KO}`
if [ -z "${KoDone}" ]; then
    # install test module
    if [ ! -f ${EMMC_KOP} ]; then
        echo "ERROR: ${EMMC_KOP} not exist"
        exit 1
    fi
    insmod ${EMMC_KOP}

    # unbind the eMMC device from the mmcblk driver
    echo mmc0:0001 > /sys/bus/mmc/drivers/mmcblk/unbind

    # bind the eMMC device to the mmc_test driver
    echo mmc0:0001 > /sys/bus/mmc/drivers/mmc_test/bind

    # mount the debugfs
    mount -t debugfs debugfs /mnt
fi

# start test
if [ ! -d /mnt/mmc0/mmc0:0001 ]; then
    echo "ERROR: /mnt/mmc0/mmc0:0001 not exist"
    exit 1
fi
cd /mnt/mmc0/mmc0:0001
for x in $(seq 45); do echo $x > test; done

# iozone test.
iozone -i 0 -i 1 -i 2 -i 6 -i 7 -i 8 -i 9 -i 12 -a -n 16m -g 128m -q 512k -Rb ./test.xls
RunRet=$?

# if run in utest, copy result to output.
if [ -f test.xls ] && [ ! -z "${UTEST_RUNOUT}" ]; then
    cp test.xls ${UTEST_RUNOUT}/${UTEST_RUNLINE}.emmc_test.xls
fi

exit ${RunRet}
