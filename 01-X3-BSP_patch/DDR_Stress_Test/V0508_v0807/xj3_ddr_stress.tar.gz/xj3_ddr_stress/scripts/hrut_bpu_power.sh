var1=`cat /sys/devices/system/bpu/bpu0/power_enable`
if [ $var1 == "-1" ];then
	echo "get bpu0 power status failed"
	exit 1
fi
var2=`cat /sys/devices/system/bpu/bpu1/power_enable`
if [ $var2 == "-1" ];then
        echo "get bpu1 power status failed"
        exit 1
fi

hrut_bpuprofile -b 2 -p 0
if [ $? -ne 0 ];then
        echo "power down 2 core failed"
        exit 1
fi


hrut_bpuprofile -b 2 -p 1
if [ $? -ne 0 ];then
	echo "power up 2 core failed"
	exit 1
fi

hrut_bpuprofile -b 0 -p 0
if [ $? -ne 0 ];then
	echo "power down core0 failed"
	exit 1
fi

var3=`cat /sys/devices/system/bpu/bpu0/power_enable`
if [ $var3 != "0" ];then
        echo "bpu0 power should be off , get power status failed"
        exit 1
fi


hrut_bpuprofile -b 0 -p 1
if [ $? -ne 0 ];then
	echo "power up  core0 failed"
	exit 1
fi

var4=`cat /sys/devices/system/bpu/bpu0/power_enable`
if [ $var4 != "1" ];then
        echo "bpu0 power should be on , get power status failed"
        exit 1
fi


hrut_bpuprofile -b 1 -p 0
if [ $? -ne 0 ];then
        echo "power down core1 failed"
        exit 1
fi

var5=`cat /sys/devices/system/bpu/bpu1/power_enable`
if [ $var5 != "0" ];then
        echo "bpu1 power should be off , get power status failed"
        exit 1
fi


hrut_bpuprofile -b 1 -p 1
if [ $? -ne 0 ];then
        echo "power up  core1 failed"
        exit 1
fi

var6=`cat /sys/devices/system/bpu/bpu1/power_enable`
if [ $var6 != "1" ];then
        echo "bpu1 power should be on , get power status failed"
        exit 1
fi

