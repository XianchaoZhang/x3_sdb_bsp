var=`cat /sys/devices/system/bpu/bpu0/devfreq/devfreq*/available_frequencies`
if [ $echo $? -ne 0 ];then
        exit 1
fi
fq1=`echo $var |awk '{print $1}'`
fq2=`echo $var |awk '{print $2}'`
fq3=`echo $var |awk '{print $3}'`

var1=`hrut_bpuprofile -b 1 -f $fq1 > /tmp/test1`
core1=`cat /tmp/test1 | awk -F ":" '{print $2}' | sed -n "1p"`
if [ $core1 != "$fq1" ];then
        echo "set bpu 1 frequencies failed,current frequencies is $core1"
        exit 1
fi

var2=`hrut_bpuprofile -b 0 -f $fq2 > /tmp/test2`
core2=`cat /tmp/test2 | awk -F ":" '{print $2}' | sed -n "1p"`
if [ $core2 != "$fq2" ];then
        echo "set bpu 0 frequencies failed,current frequencies is $core2"
        exit 1
fi

var3=`hrut_bpuprofile -b 2 -f $fq3 > /tmp/test3`
core3=`cat /tmp/test3 | awk -F ":" '{print $2}' | sed -n "1p"`
core4=`cat /tmp/test3 | awk -F ":" '{print $2}' | sed -n "2p"`
if [ $core3 != "$fq3" ] && [ $core4 != "$fq3" ];then
        echo "set all bpu frequencies failed,current frequencies is $core3 and $core4"
        exit 1
fi
rm /tmp/test1
rm /tmp/test2
rm /tmp/test3
