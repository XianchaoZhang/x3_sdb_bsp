var=`hrut_bpuprofile -b 2 -r 1 > /tmp/test1`
bpu0cpu=`cat /tmp/test1 |grep '%' |tail -n 1 | awk '{print $2}'`
bpu1cpu=`cat /tmp/test1 |grep '%' |head -n 1 | awk '{print $2}'`

if [ $bpu0cpu == "0%" ] && [ $bpu1cpu == "0%" ];then
	echo "bpu1 cpu is $bpu0cpu"
	echo "bpu0 cpu is $bpu1cpu"
else
	echo "get cpu % failed,and bpu1 cpu is $bpu0cpu , bpu0 cpu is $bpu1cpu"
	exit 1
fi
rm /tmp/test1
