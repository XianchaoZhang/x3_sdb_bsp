var1=`hrut_ip g`
getip=`echo $var1 | awk '{print $1}' | sed -n '1p'`

hrut_ip s 182.168.1.10
var2=`hrut_ip g`
if [ $var2 == "182.168.1.10" ];then
	echo "set ip pass"
else
	echo "hrut ip set failed"
	exit 1
fi

hrut_ip c
var3=`hrut_ip g`
evar3=`echo $var3 | awk '{print $1}' | sed -n '1p'`
if [ $evar3 == "0.0.0.0" ] || [ $evar3 == "192.168.1.10" ];then
        echo "reset ip pass"
else
        echo "hrut_ip reset ip failed"
        exit 1
fi

if [ x"$getip" != x"0.0.0.0" ];then
    hrut_ip s $getip
    if [ $? -ne 0 ];then
	    echo "recover default hrut_ip failed"
	    exit 1
    fi
fi

fullvar1=`hrut_ipfull g`
getip1=`echo "$fullvar1" | awk -F "=" '{print $2}' |sed -n '1p'`
getmask1=`echo "$fullvar1" | awk -F "=" '{print $2}' |sed -n '2p'`
getgw1=`echo "$fullvar1" | awk -F "=" '{print $2}' |sed -n '3p'`

hrut_ipfull s 182.168.1.10 255.255.255.0 182.168.1.1
fullvar2=`hrut_ipfull g`
getip2=`echo "$fullvar2" | awk -F "=" '{print $2}' |sed -n '1p'`
getgw2=`echo "$fullvar2" | awk -F "=" '{print $2}' |sed -n '3p'`
if [ $getip2 == "182.168.1.10" ] && [ $getgw2 == "182.168.1.1" ];then
	echo "set ip pass"
else
	echo "hrut ip set failed"
	exit 1
fi

hrut_ipfull c
if [ x"$getip1" != x"0.0.0.0" ];then
    hrut_ipfull s $getip1 $getmask1 $getgw1
    fullvar3=`hrut_ipfull g`
    getip3=`echo "$fullvar3" | awk -F "=" '{print $2}' |sed -n '1p'`
    getmask3=`echo "$fullvar3" | awk -F "=" '{print $2}' |sed -n '2p'`
    getgw3=`echo "$fullvar3" | awk -F "=" '{print $2}' |sed -n '3p'`
    if [ $getip3 == $getip1 ] && [ $getgw3 == $getgw1 ];then
	    echo "set ip pass"
    else
	    echo "hrut ip set failed"
	    exit 1
    fi
fi

