var=`hrut_mac g`
if [ $? -ne 0 ];then
	echo "get hrut mac failed"
	exit 1
fi

hrut_mac s aa:bb:cc:dd:ee:ff
var1=`hrut_mac g`
if [ $var1 == "aa:bb:cc:dd:ee:ff" ];then
	echo "set hrut mac pass"
else
	echo "set hrut mac failed"
	exit 1
fi

hrut_mac s $var
var2=`hrut_mac g`
if [ $var == $var ];then
	echo "recover mac pass"
else
	echo "recover mac failed"
	exit 1
fi
