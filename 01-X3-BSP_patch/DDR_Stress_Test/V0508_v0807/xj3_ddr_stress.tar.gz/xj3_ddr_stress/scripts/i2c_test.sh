#!/bin/sh

total_i2c_bus=`/app/bin/i2cdetect_count -l | wc -l`

#echo $total_i2c_bus

if [ $total_i2c_bus -lt 1 ];then
	echo "No I2C Bus Detected."
	exit 1
fi

drv_cnt=0
dev_cnt=0
for i in $(seq 0 $(expr $total_i2c_bus - 1))
do
	`/app/bin/i2cdetect_count -y $i > /tmp/i2c_bus$i.log`
	((drv_cnt=$(grep Drivers /tmp/i2c_bus$i.log | awk '{print $1;}')+$drv_cnt))
	((dev_cnt=$(grep Devices /tmp/i2c_bus$i.log | awk '{print $1;}')+$dev_cnt))
done

echo "Total I2C Buses: $total_i2c_bus"
echo "Total I2C Drivers detected: $drv_cnt"
echo "Total I2C Devices detected: $dev_cnt"
rm /tmp/i2c_bus*.log
