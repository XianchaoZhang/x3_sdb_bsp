for i in 1 2 3 4 5
do
	test_time=$1
	server_ip=$2
	log=/tmp/iperf.log
	echo > $log
	iperf3 -c ${server_ip} -f m -i 1 -t $test_time --logfile $log
	if [ $? -eq 0 ];then
		exit 0
	else
		grep -q "busy" $log
		if [ $? -eq 0 ];then
			wait_time=`expr $test_time + 5`
			echo "server busy, retry $i after $wait_time seconds"
			sleep  $wait_time
		else
			cat $log
			exit 1
		fi
	fi
done

exit 1
