#!/bin/sh

##################################################
# read/write test
##################################################
offset=0x6F40000
size=0xEC0000
cnt=$(($size/2048))
echo "offset: $offset, size: $size, cnt: $cnt"

dd if=/dev/urandom of=tt.dat bs=2k count=$cnt
a=`md5sum tt.dat | awk '{printf $1}'`
flash_erase /dev/mtd0 0 0
mtd_debug write /dev/mtd0 0x6F40000 0xEC0000 tt.dat
mtd_debug read /dev/mtd0 0x6F40000 0xEC0000 dd.dat
b=`md5sum dd.dat | awk '{printf $1}'`

if [ "$a" != "$b" ];then
        echo "mtdflash test failed!"
        exit -1
fi
rm *.dat
echo "mtdflash test ok!"
