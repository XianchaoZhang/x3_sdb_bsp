#!/bin/sh

num=8
dir="/sys/class/regulator/regulator."

for i in $(seq 1 $num)
do
	if [ ! -d "$dir""$i" ];then
		echo "regulator test fail!"
		exit -1
	fi
done

