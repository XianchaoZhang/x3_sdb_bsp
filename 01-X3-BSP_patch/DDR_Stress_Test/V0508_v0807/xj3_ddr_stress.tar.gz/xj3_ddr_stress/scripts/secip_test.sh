insmod /lib/modules/4.14.74/elppdu.ko
insmod /lib/modules/4.14.74/elpmem.ko
insmod /lib/modules/4.14.74/elpspacc.ko
insmod /lib/modules/4.14.74/elpspaccdev.ko
insmod /lib/modules/4.14.74/elpspacccrypto.ko
insmod /lib/modules/4.14.74/elprsa.ko
insmod /lib/modules/4.14.74/elpclp800.ko

count=0
cd /app/scripts/secip_test

sh 0_test_proc_crypto.sh
if [ ! $? -eq 0 ];then
	echo "0_test_proc_crypto failed."
	count=`expr $count + 1`
fi

sh 1_test_crypto_drv.sh
if [ ! $? -eq 0 ];then
	echo "1_test_crypto_drv failed."
	count=`expr $count + 1`
fi

sh 2_test_secip_api.sh
if [ ! $? -eq 0 ];then
	echo "2_test_secip_api failed."
	count=`expr $count + 1`
fi

sh 3_test_pka_function.sh
if [ ! $? -eq 0 ];then
	echo "3_test_pka_function failed."
	count=`expr $count + 1`
fi

sh 4_test_trng_reset.sh
if [ ! $? -eq 0 ];then
	echo "4_test_trng_reset failed."
	count=`expr $count + 1`
fi

if [ ! $count -eq 0 ];then
	echo "secip test failed."
	exit 1
fi

echo "secip test passed."


rmmod /lib/modules/4.14.74/elprsa.ko
rmmod /lib/modules/4.14.74/elpclp800.ko
rmmod /lib/modules/4.14.74/elpspacccrypto.ko
rmmod /lib/modules/4.14.74/elpspaccdev.ko
rmmod /lib/modules/4.14.74/elpspacc.ko
rmmod /lib/modules/4.14.74/elpmem.ko
rmmod /lib/modules/4.14.74/elppdu.ko
