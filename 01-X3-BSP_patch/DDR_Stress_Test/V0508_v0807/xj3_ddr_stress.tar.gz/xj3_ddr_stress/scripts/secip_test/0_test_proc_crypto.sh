echo "secip: check crypto driver kernel selftest"

TMP_FNAME=.crypto.tmp.txt

for alg in "md5" "sha1" "sha256" "sha512"\
			"hmac(sha1)" "hmac(sha256)" "hmac(sha512)"\
			"ecb(aes)" "cbc(aes)" "ctr(aes)"\
			"ecb(des)" "cbc(des)" "ecb(des3_ede)" "cbc(des3_ede)"
do
        echo -n "$alg    "
        grep -A 8 "name         : $alg" /proc/crypto > $TMP_FNAME
        grep -q "selftest     : passed" $TMP_FNAME
        if [ $? -eq 0 ];then
                echo "passed"
        else
                echo "failed"
                exit 1
        fi
done

rm -f $TMP_FNAME
#rmmod elpspacccrypto
echo "secip: check crypto driver kernel selftest passed."
