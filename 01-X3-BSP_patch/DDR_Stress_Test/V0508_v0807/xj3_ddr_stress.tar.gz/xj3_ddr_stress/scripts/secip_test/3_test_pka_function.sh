echo "insmod /lib/modules/elprsa.ko"

printf "\n\n3.1_run_rsa_encrypt_pub.sh start ...\n\n"
sh 3.1_run_rsa_encrypt_pub.sh

if [ ! $? -eq 0 ];then
	echo "3.1_run_rsa_encrypt_pub failed"
	exit 255
fi

echo "3.1_run_rsa_encrypt_pub passed"

printf "\n\n3.2_rsa_sign.sh start ...\n\n"
sh 3.2_rsa_sign.sh

if [ ! $? -eq 0 ];then
	echo 3.2_"rsa_sign failed"
	exit 255
fi

echo "3.2_rsa_sign passed"
