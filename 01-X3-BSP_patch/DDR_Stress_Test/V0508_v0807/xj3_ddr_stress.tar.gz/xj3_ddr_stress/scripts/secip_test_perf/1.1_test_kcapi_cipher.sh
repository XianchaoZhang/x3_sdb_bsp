echo "secip: test crypto driver with libkcapi app"
echo "run insmod /lib/modules/elpspacccrypto.ko before test HW crypto"

keyfile="keybox"
#$1: data_size, $2:cipher name, $3 keylen, $4 ivlen $5 enc/dec
function run_cipher
{
	blk_sz=4096
	data_sz=$1
	total_sz_MB=100

	if [ $data_sz -lt 1048577 ]; then
		total_sz_MB=10
	fi

	total_sz=`expr 1048576 \* $total_sz_MB`

	cipher=$2
	keylen=$3
	ivlen=$4
	cnt=`expr $data_sz / $blk_sz`
	fname=test.${data_sz}.data
	dd if=/dev/urandom of=$fname bs=$blk_sz count=$cnt &> /dev/null

	iv=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom | cut -c -${ivlen}`
	key=`hexdump  -n 16 -e '4/4 "%08x" 1 "\n"' /dev/urandom | cut -c -${keylen}`
	echo -n "$key" > $keyfile

	iter_cnt=`expr $total_sz / $data_sz`

	if [ "$5" == "dec" ];then
		exec 10<$keyfile; kcapi-enc --keyfd 10 -e -c $cipher --iv "$iv" -i ${fname} -o ${fname}.enc
	fi

	time_ms_before=$(($(date +%s%3N)))

	for i in `seq 1 1 $iter_cnt`;
	do
		if [ "$5" == "enc" ];then
			exec 10<$keyfile; kcapi-enc --keyfd 10 -e -c $cipher --iv "$iv" -i ${fname} -o ${fname}.enc
		fi
		if [ "$5" == "dec" ];then
			exec 10<$keyfile; kcapi-enc --keyfd 10 -d -c $cipher --iv "$iv" -i ${fname}.enc -o ${fname}.dec
		fi
	#	cmp ${fname} ${fname}.dec
	done

	time_ms_after=$(($(date +%s%3N)))

	if [ "$5" == "enc" ];then
		exec 10<$keyfile; kcapi-enc --keyfd 10 -d -c $cipher --iv "$iv" -i ${fname}.enc -o ${fname}.dec
	fi

	time_diff=`expr $time_ms_after - $time_ms_before`

	speed=`expr $total_sz_MB \* 1000000 / $time_diff`

	printf "%s speed with size:%-12d keylen:%d is %dKB/s\n" \
			$cipher $data_sz $keylen $speed

}

if [ $# -lt 1 ];then
	echo "Usage $0 enc|dec"
	exit 1
fi

for cipher in "ecb(aes)" "cbc(aes)" "ctr(aes)"
do
	echo
	echo "test $cipher"
	echo
	for size in 4096 16384  65536 1048576 10485760 104857600
	do
		run_cipher $size $cipher 16 16 $1
	done

	for size in 4096 16384  65536 1048576 10485760 104857600
	do
		run_cipher $size $cipher 24 16 $1
	done

	for size in 4096 16384  65536 1048576 10485760 104857600
	do
		run_cipher $size $cipher 32 16 $1
	done
done


for cipher in "ecb(des)" "cbc(des)"
do
	echo
	echo "test $cipher"
	echo
	for size in 4096 16384  65536 1048576 10485760 104857600
	do
		run_cipher $size $cipher 8 8 $1
	done
done

for cipher in "ecb(des3_ede)" "cbc(des3_ede)"
do
	echo
	echo "test $cipher"
	echo
	for size in 4096 16384  65536 1048576 10485760 104857600
	do
		run_cipher $size $cipher 24 8 $1
	done
done


