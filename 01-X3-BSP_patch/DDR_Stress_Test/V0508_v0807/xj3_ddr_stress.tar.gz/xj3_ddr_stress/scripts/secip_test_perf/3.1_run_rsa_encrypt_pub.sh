export OPENSSL_CONF=$PWD/rsa_engine.cnf
insmod /lib/modules/elprsa.ko

# A generates private key `priv_key.pem`
openssl genrsa -out priv_key.pem 2048

# A extracts the public key `pub_key.pem` and sends it to B
openssl rsa -pubout -in priv_key.pem -out pub_key.pem

NUM=100
if [ ! $1 == "" ];then
	NUM=$1
fi

time_ms_before=$(($(date +%s%3N))) 
for i in `seq 1 1 $NUM`
do
# B encrypts a message and sends `encrypted_with_pub_key` to A
openssl rsautl -encrypt -in cleartext -out encrypted_with_pub_key -inkey pub_key.pem -pubin

# A decrypts B's message
openssl rsautl -decrypt -in encrypted_with_pub_key -inkey priv_key.pem > cleartext.dec
done

time_ms_after=$(($(date +%s%3N))) 


time_diff=`expr $time_ms_after - $time_ms_before`
printf "%d times rsa enc/dev takes %d ms\n" $NUM $time_diff

cmp cleartext.dec cleartext

if [ ! $? -eq 0 ];then
	exit 255
fi
