mnt_dev=`cat /proc/mounts |grep "/mnt" |awk '{print $1}'`
if [ -n "$mnt_dev" ]; then
	app_dev=`cat /proc/mounts |grep "/app" |awk '{print $1}'`
	if [ -n "$app_dev" ]; then
		umount /app
	fi
	mount $mnt_dev /app -o sync
fi
exit 0
