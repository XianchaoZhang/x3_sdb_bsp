var=`hrut_somid g`

hrut_somid s 16
var1=`hrut_somid g --eeprom`
var2=`hrut_somid g`
if [ $var2 != "16" ];then
	echo "hrut_somid s 16 failed"
	exit 1
fi

var3=`hrut_somid s 17`
echovar3=`echo "$var3" | awk '{print $1}' | sed -n '1p'`
if [ $echovar3 != "invalid" ];then
	echo "hrut_somid s 17 failed"
	exit 1
fi

hrut_somid g --eeprom 
hrut_somid g

hrut_somid s 16
hrut_somid g --eeprom 
hrut_somid g
hrut_somid c
hrut_somid g --eeprom 
var4=`hrut_somid g`
if [ $var4 != 0 ];then
	echo "hrut_somid c failed"
	exit 1
fi

