#!/bin/sh

sensor0=`cat /sys/class/hwmon/hwmon0/name`

if [ $# = 1 ]&&[ $1 = "skj2som" ];then
	if [ $sensor0 = "x2_temp" ]; then
		echo "sk temp sensor 0 test pass!!!"
		exit 0
	else
		exit 1
	fi
fi

sensor1=`cat /sys/class/hwmon/hwmon1/name`

if [ $sensor0 = "tmp75c" ]
then
        echo "temp sensor 0 test pass!!!"
        exit 0
elif [ $sensor1 = "tmp75c" ]
then
        echo "temp sensor 1 test pass!!!"
        exit 0
else
        exit 1
fi

