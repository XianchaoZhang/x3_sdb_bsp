sh /app/scripts/test-i2c.sh > /tmp/1test
var=`cat /tmp/1test |awk '{print $2}'|tail -n 2  |sed -n '1p'`
if [ $var == "OK" ];then
	echo "test i2c pass"
else
	echo "test i2c failed"
	exit 1
fi
rm /tmp/1test