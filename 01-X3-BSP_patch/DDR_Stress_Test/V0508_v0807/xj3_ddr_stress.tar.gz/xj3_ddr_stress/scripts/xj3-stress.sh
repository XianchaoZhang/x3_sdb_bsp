#1 cpu test
echo 4 > /proc/sys/vm/drop_caches
nohup /userdata/xj3_ddr_stress/bin/stressapptest -s 172800 -M 100 -f /tmp/sat.io1 -f /tmp/sat.io2 -i 4 -m 8 -C 2 -W >/userdata/cpu-stress.log &
#2 bpu test
nohup /userdata/xj3_ddr_stress/scripts/run-portion.sh -b 2 -p 100 >/userdata/bpu-stress.log &
#3 ipu test

#4 others
