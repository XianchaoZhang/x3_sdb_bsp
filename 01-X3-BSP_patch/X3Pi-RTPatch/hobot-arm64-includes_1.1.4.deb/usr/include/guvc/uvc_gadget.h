/* SPDX-License-Identifier: LGPL-2.1-or-later */
/*
 * uvc_gadget.h
 *	uvc gadget work routine and functions
 *	current base code from https://github.com/wlhe/uvc-gadget
 *	net stage will replace with http://git.ideasonboard.org/uvc-gadget.git
 *
 * Copyright (C) 2019 Horizon Robotics, Inc.
 *
 * Contact: jianghe xu<jianghe.xu@horizon.ai>
 */

#ifndef _UVC_GADGET_H_
#define _UVC_GADGET_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <linux/usb/ch9.h>
#include <linux/usb/video.h>
#include <linux/videodev2.h>

#include "uvc.h"

/* hidden symbols for some native api */
#define NATIVE_ATTR_ __attribute__((visibility ("hidden")))

/* below h265 definition in kernel include/uapi/linux/videodev2.h,
 * but user app use toolchain's include file
 */
#define V4L2_PIX_FMT_H265     v4l2_fourcc('H', '2', '6', '5') /* H265 with start codes */

#define CLEAR(x) memset(&(x), 0, sizeof(x))
#define max(a, b) (((a) > (b)) ? (a) : (b))

#define clamp(val, min, max)                                                                                           \
    ({                                                                                                                 \
        typeof(val) __val = (val);                                                                                     \
        typeof(min) __min = (min);                                                                                     \
        typeof(max) __max = (max);                                                                                     \
        (void)(&__val == &__min);                                                                                      \
        (void)(&__val == &__max);                                                                                      \
        __val = __val < __min ? __min : __val;                                                                         \
        __val > __max ? __max : __val;                                                                                 \
    })

#define ARRAY_SIZE(a) ((sizeof(a) / sizeof(a[0])))
#define pixfmtstr(x) (x) & 0xff, ((x) >> 8) & 0xff, ((x) >> 16) & 0xff, ((x) >> 24) & 0xff

struct uvc_context;

/* ---------------------------------------------------------------------------
 * Generic stuff
 */

/*
 * Note: terminal and unit id is form terminal and unit desciptor in uvc dev driver.
 * so each uvc device has different uvc unit and termial id.
 */
#define UVC_CTRL_INTERFACE_ID 0
#define UVC_CTRL_CAMERA_TERMINAL_ID 1
#define UVC_CTRL_PROCESSING_UNIT_ID 2
#define UVC_CTRL_OUTPUT_TERMINAL_ID 3
#define UVC_CTRL_EXTENSION_UNIT_ID  4

/* h264 nalu enum */
enum {
	H264_NALU_IDR = 5,
	H264_NALU_SPS = 7,
	H264_NALU_PPS = 8,
};

/* IO methods supported */
enum io_method {
	IO_METHOD_MMAP,
	IO_METHOD_USERPTR,
};


/* callback function definitions */
typedef int (*uvc_prepare_buffer_callback_fn) (struct uvc_context *ctx,
					       void **buf_to, int *buf_len,
					       void **entity, void *userdata);
typedef void (*uvc_release_buffer_callback_fn) (struct uvc_context *ctx,
						void **entity, void *userdata);
typedef void (*uvc_streamon_callback_fn) (struct uvc_context *ctx, int is_on,
					  void *userdata);
typedef int (*uvc_event_setup_callback_fn) (struct uvc_context *ctx,
				uint8_t req, uint8_t cs, uint8_t entity_id,
				struct uvc_request_data *resp,
				void *userdata);
typedef int (*uvc_event_data_callback_fn) (struct uvc_context *ctx,
				uint8_t req, uint8_t cs, uint8_t entity_id,
				struct uvc_request_data *data,
				void *userdata);

/* prepare buffer callback */
struct uvc_prepare_callback {
	uvc_prepare_buffer_callback_fn cb;
	void *userdata;
};

/* release buffer callback */
struct uvc_release_callback {
	uvc_release_buffer_callback_fn cb;
	void *userdata;
};

/* stream on callback */
struct uvc_streamon_callback {
	uvc_streamon_callback_fn cb;
	void *userdata;
};

/* control event callback */
struct uvc_event_callback {
	uvc_event_setup_callback_fn setup_f;
	uvc_event_data_callback_fn data_f;
	void *userdata;
};

/* Buffer representing one video frame */
struct buffer {
	struct v4l2_buffer buf;
	void *start;
	size_t length;
};

/* uvc control context structure */
struct uvc_control_context {
	uint8_t req;
	uint8_t cs;
	uint8_t id;
	uint8_t intf;
};

/* ---------------------------------------------------------------------------
 * V4L2 and UVC device instances
 */

/* Represents a V4L2 based video capture device */
struct v4l2_device {
	/* v4l2 device specific */
	int v4l2_fd;
	int is_streaming;
	char *v4l2_devname;

	/* v4l2 buffer specific */
	enum io_method io;
	struct buffer *mem;
	unsigned int nbufs;

	/* v4l2 buffer queue and dequeue counters */
	unsigned long long int qbuf_count;
	unsigned long long int dqbuf_count;

	/* uvc device hook */
	struct uvc_device *udev;
};

/* Represents a UVC based video output device */
struct uvc_device {
	/* uvc device specific */
	int uvc_fd;
	int is_streaming;
	int run_standalone;
	char uvc_devname[128];

	/* uvc control request specific */

	struct uvc_control_context context;
	struct uvc_streaming_control probe;
	struct uvc_streaming_control commit;
	unsigned int control_interface;
	unsigned int streaming_interface;
	int control;
	int event_mask;
	struct uvc_request_data request_error_code;
	unsigned int brightness_val;

	/* uvc buffer specific */
	enum io_method io;
	struct buffer *mem;
	struct buffer *dummy_buf;
	unsigned int nbufs;
	unsigned int fcc;
	unsigned int width;
	unsigned int height;

	unsigned int bulk;
	uint8_t color;
	unsigned int imgsize;
	void *imgdata;

	unsigned int bufsize;
	void *videobuf;
	void *entity;

	/* USB speed specific */
	int mult;
	int burst;
	int maxpkt;
	int maxpkt_quirk;
	enum usb_device_speed speed;
	enum usb_device_speed conn_speed;

	/* h264 sequence header (special case)*/
	char sps_pps[128];
	int sps_pps_size;
	int got_spspps;
	int idr_idx;
	int h264_quirk;

	/* uvc streaming multi alternate settings */
	int mult_alts;

	/* uvc specific flags */
	int first_buffer_queued;
	int uvc_shutdown_requested;

	/* uvc buffer queue and dequeue counters */
	unsigned long long int qbuf_count;
	unsigned long long int dqbuf_count;

	/* v4l2 device hook */
	struct v4l2_device *vdev;

	/* parent */
	void *parent;

	/* uvc prepar, release & streamon callback&state */
	struct uvc_prepare_callback prepare_cb;
	struct uvc_release_callback release_cb;
	struct uvc_streamon_callback streamon_cb;
	struct uvc_event_callback event_cb;
};

struct uvc_context {
	struct uvc_device *udev;	/* uvc v4l2 output device */
	struct v4l2_device *vdev;	/* option: v4l2 capture device (such as vivid) */
	pthread_t uvc_pid;
	int exit;
};

/* ---------------------------------------------------------------------------
 * V4L2 generic stuff
 */
NATIVE_ATTR_ int v4l2_open(struct v4l2_device **v4l2, char *devname,
			struct v4l2_format *s_fmt);
NATIVE_ATTR_ int v4l2_reqbufs(struct v4l2_device *dev, int nbufs);
NATIVE_ATTR_ int v4l2_start_capturing(struct v4l2_device *dev);
NATIVE_ATTR_ int v4l2_process_data(struct v4l2_device *dev);
NATIVE_ATTR_ int v4l2_stop_capturing(struct v4l2_device *dev);
NATIVE_ATTR_ int v4l2_uninit_device(struct v4l2_device *dev);
NATIVE_ATTR_ void v4l2_close(struct v4l2_device *dev);

/* ---------------------------------------------------------------------------
 * UVC generic stuff
 */
NATIVE_ATTR_ int uvc_open(struct uvc_device **uvc, char *devname);
NATIVE_ATTR_ int uvc_video_set_format(struct uvc_device *dev);
NATIVE_ATTR_ void uvc_events_init(struct uvc_device *dev);
NATIVE_ATTR_ int uvc_video_reqbufs(struct uvc_device *dev, int nbufs);
NATIVE_ATTR_ int uvc_video_stream(struct uvc_device *dev, int enable);
NATIVE_ATTR_ void uvc_events_process(struct uvc_device *dev);
NATIVE_ATTR_ int uvc_video_process(struct uvc_device *dev);
NATIVE_ATTR_ int uvc_uninit_device(struct uvc_device *dev);
NATIVE_ATTR_ void uvc_close(struct uvc_device *dev);
NATIVE_ATTR_ int uvc_set_maxpkt_quirk(struct uvc_device *dev);
/* ---------------------------------------------------------------------------
 * Some helper function
 */
const char *fcc_to_string(unsigned int fcc);

#ifdef __cplusplus
}
#endif

#endif /* _UVC_GADGET_H_ */
