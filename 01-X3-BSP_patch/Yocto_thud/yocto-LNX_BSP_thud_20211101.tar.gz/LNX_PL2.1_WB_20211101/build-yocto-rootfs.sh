#!/bin/bash

if [ $# != 1 ]
then
	echo "Usage: ./build-yocto-rootfs.sh xj3-hobot-image"
	exit 1
fi

# start clone poky
if [ ! -d ./poky ]
then
	echo "start download poky..."
	git clone git://git.yoctoproject.org/poky
	sleep 1
else
	echo "poky is existed"
	cd poky
	. oe-init-build-env
	sleep 2
	bitbake	$1
	exit 1
fi

if [ ! -d ./meta-openembedded ]
then
	echo "start download meta-openembedded"
	git clone git://git.openembedded.org/meta-openembedded
else
	echo "meta-openembedded is exist!"
fi

cp -rf ./meta-horizon ./poky
cp -rf ./meta-openembedded ./poky

# word on thud branch
cd poky
TOPDIR=`pwd`
git checkout thud
cd ${TOPDIR}/meta-openembedded
git checkout thud
cd ${TOPDIR}

# Start patching the horizon
git apply meta-horizon/conf/horizon-thud-patch/0001-meta.patch
git apply meta-horizon/conf/horizon-thud-patch/0002-meta-poky.patch
git apply meta-horizon/conf/horizon-thud-patch/0003-scripts.patch

cp ${TOPDIR}/../local.conf.sample meta-poky/conf/
cp ${TOPDIR}/../bblayers.conf.sample meta-poky/conf/
# start build xj3-hobot-image
. oe-init-build-env
sleep 2
bitbake $1
