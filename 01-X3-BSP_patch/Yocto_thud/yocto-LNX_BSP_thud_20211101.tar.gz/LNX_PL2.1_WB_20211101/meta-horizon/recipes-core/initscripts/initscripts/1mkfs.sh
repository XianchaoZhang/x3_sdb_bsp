#!/bin/sh

part_number()
{
    for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16;do
        num=`expr $i \* 128`
        num=`expr $num + 952`
        gpt=$(hexdump -s $num -n 64 -e '16/1 "%c"' /dev/mmcblk0 | tr -d '\0' | sed 's/\*//g')
        gpt=$(echo "$gpt" | sed 's/ary//g' | sed 's/ubooty/uboot/g')

        if [ -z $gpt ];then
            i=255
            return $i
        fi

        if [ $gpt = $1 ];then
            return $i
        fi
    done
}

part_number "app"
part_id=$?
#echo "part_id = $part_id"
mount -t ext4 /dev/mmcblk0p${part_id} /app > /dev/null 2>&1
ret=$?
#echo "ret:$ret"
if [ $ret -ne 0 ];then
    mkfs.ext4 -O 64bit -L app -F /dev/mmcblk0p${part_id}
else
    umount /app
fi

part_number "userdata"
part_id=$?
#echo "part_id = $part_id"
mount -t ext4 /dev/mmcblk0p${part_id} /userdata > /dev/null 2>&1
ret=$?
#echo "ret:$ret"
if [ $ret -ne 0 ];then
    mkfs.ext4 -O 64bit -L userdata -F /dev/mmcblk0p${part_id}
else
    umount /userdata
fi

device="/dev/mtd2"
if [ -c $device ];then
    mkdir -p /mnt
    ubiattach   -m 2 -d 1
    mount -t ubifs  /dev/ubi1_1 /mnt -o sync
fi

#[ ! -f "/etc/mkfs_mmcblk0p5.done" ] && mkfs.ext4 -O 64bit -F /dev/mmcblk0p5 && touch /etc/mkfs_mmcblk0p5.done
#[ ! -f "/etc/mkfs_mmcblk0p6.done" ] && mkfs.ext4 -O 64bit -F /dev/mmcblk0p6 && touch /etc/mkfs_mmcblk0p6.done

