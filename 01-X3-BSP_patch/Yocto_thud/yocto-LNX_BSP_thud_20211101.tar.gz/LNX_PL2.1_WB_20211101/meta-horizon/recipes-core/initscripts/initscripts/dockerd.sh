#!/bin/sh
if [ -f "/etc/rc5.d/S98dockerd.sh" ];then
    /etc/rc5.d/S98dockerd.sh
fi