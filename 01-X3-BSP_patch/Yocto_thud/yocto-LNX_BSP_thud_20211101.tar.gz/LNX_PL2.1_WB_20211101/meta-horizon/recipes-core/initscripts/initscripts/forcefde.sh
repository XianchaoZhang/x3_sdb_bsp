#!/bin/sh
#
# forcefde   force encrypt userdata partition
#
#

BOOTUP=color
SETCOLOR_SUCCESS="echo -en \\033[1;32m"
SETCOLOR_FAILURE="echo -en \\033[1;31m"

echo_success() {
    [ "$BOOTUP" = "color" ] && $MOVE_TO_COL
    echo -n "["
    [ "$BOOTUP" = "color" ] && $SETCOLOR_SUCCESS
    echo -n "$1  OK  "
    [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
    echo -n "]"
    echo -ne "\r"
    return 0
}

echo_failure() {
    [ "$BOOTUP" = "color" ] && $MOVE_TO_COL
    echo -n "["
    [ "$BOOTUP" = "color" ] && $SETCOLOR_FAILURE
    echo -n "$1 FAILED"
    [ "$BOOTUP" = "color" ] && $SETCOLOR_NORMAL
    echo -n "]"
    echo -ne "\r"
    return 1
}

# Log that something succeeded
success() {
    [ "$BOOTUP" != "verbose" -a -z "${LSB:-}" ] && echo_success $1
    return 0
}

# Log that something failed
failure() {
    local rc=$?
    [ "$BOOTUP" != "verbose" -a -z "${LSB:-}" ] && echo_failure $1
    return $rc
}

key_is_random() {
    [ "$1" = "/dev/urandom" -o "$1" = "/dev/hw_random" \
    -o "$1" = "/dev/random" ]
}

find_crypto_mount_point() {
    local fs_spec fs_file fs_vfstype remaining_fields
    local fs
    while read fs_spec fs_file remaining_fields; do
        if [ "$fs_spec" = "/dev/mapper/$1" ]; then
            echo $fs_file
            break;
        fi
    done < /etc/userfstab
}

# Because of a chicken/egg problem, init_crypto must be run twice.  /var may be
# encrypted but /var/lib/random-seed is needed to initialize swap.
init_crypto() {
    local have_random dst src key opt mode owner params makeswap skip arg opt
    local param value rc ret mke2fs mdir mount_point

    ret=0
    have_random=$1
    while read dst src opt key; do
    [ -z "$dst" -o "${dst#\#}" != "$dst" ] && continue
    [ -b "/dev/mapper/$dst" ] && continue;
    if [ "$have_random" = 0 ] && key_is_random "$key"; then
        continue
    fi
    if [ -n "$key" -a "x$key" != "xnone" ]; then
        if test -e "$key" ; then
            mode=$(ls -l "$key" | cut -c 5-10)
            owner=$(ls -l $key | awk '{ print $3 }')
            if [ "$mode" != "------" ] && ! key_is_random "$key"; then
                echo "INSECURE MODE FOR $key"
            fi
            if [ "$owner" != root ]; then
                echo "INSECURE OWNER FOR $key"
            fi
            else
                echo "Key file for $dst not found"
            fi
        else
            key=""
    fi
    params=""
    makeswap=""
    mke2fs=""
    skip=""
    # Parse the src field for UUID= and convert to real device names
    if [ "${src%%=*}" == "UUID" ]; then
        src=$(/sbin/blkid -t "$src" -l -o device)
    elif [ "${src/^\/dev\/disk\/by-uuid\/}" != "$src" ]; then
        src=$(__readlink $src)
    fi
    # Is it a block device?
    [ -b "$src" ] || continue
    # Is it already a device mapper slave? (this is gross)
    devesc=${src##/dev/}
    devesc=${devesc//\//!}
    for d in /sys/block/dm-*/slaves ; do
        [ -e $d/$devesc ] && continue 2
    done
    # Parse the options field, convert to cryptsetup parameters
    # and contruct the command line
    while [ -n "$opt" ]; do
        arg=${opt%%,*}
        opt=${opt##$arg}
        opt=${opt##,}
        param=${arg%%=*}
        value=${arg##$param=}

        case "$param" in
        cipher)
            echo "CRYPTSETUP: cipher value: $value"
            params="$params -c $value"
            if [ -z "$value" ]; then
                echo $"$dst: no value for cipher option, skipping"
                skip="yes"
            fi
        ;;
        size)
            params="$params -s $value"
            if [ -z "$value" ]; then
                echo  $"$dst: no value for size option, skipping"
                skip="yes"
            fi
        ;;
        hash)
            params="$params -h $value"
            if [ -z "$value" ]; then
                echo $"$dst: no value for hash option, skipping\n"
                skip="yes"
            fi
        ;;
        verify)
            params="$params -y"
        ;;
        swap)
            makeswap=yes
        ;;
        tmp)
            mke2fs=yes
        esac
    done
    if [ "$skip" = "yes" ]; then
        ret=1
        continue
    fi
    echo "CRYPTSETUP: $src"
    if cryptsetup isLuks "$src" 2>/dev/null; then
        if key_is_random "$key"; then
            echo "$dst: LUKS requires non-random key, skipping\n"
            ret=1
            continue
        fi
        echo "CRYPTSETUP: $params"
        #echo "CRYPTSETUP: key:$key src:$src dst:$dst"
        if test -e "$key" ; then
		    /sbin/cryptsetup $params luksOpen --test-passphrase ${key:+-d $key} "$src"
            rc=$?
        else
            rc=1
        fi
       if [ $rc -ne 0 ]; then
           if test -e "$key" ; then
               rm $key
           fi
           /sbin/cryptsetup $params luksOpen "$src" "$dst" <&1
           rc=$?
           if [ $rc -ne 0 ]; then
               ret=1
               return $ret
            fi
        else
            /sbin/cryptsetup ${key:+-d $key} $params -v luksOpen "$src" "$dst" <&1
            rc=$?
            if [ $rc -ne 0 ]; then
                ret=1
                return $ret;
	        fi
        fi
	else	    
        echo "CRYPTSETUP: key:$key src:$src dst:$dst"
        #/sbin/cryptsetup $params ${key:+-d $key} -v create "$dst" "$src" <&1 2>/dev/null
        #source /etc/init.d/forceencrypt.sh $src $dst $mount_point "$key" "$params"
        umount $src
        cryptsetup $params -q luksFormat $src -d $key
        rc=$?
        if [ $rc -ne 0 ]; then
            echo "format fail"
            return $rc
        else
            cryptsetup $params luksOpen $src $dst -d $key
            mkfs.ext4 /dev/mapper/$dst
        fi
       
        rc=$?
        if [ $rc -ne 0 ];then
            echo "encrypt $src<or $mount_point> fail"
            return $rc;
        fi
    fi
    echo "CRYPTSETUP: $dst"
    if [ -b "/dev/mapper/$dst" ]; then
        if [ "$makeswap" = "yes" ]; then
            mkswap "/dev/mapper/$dst" 2>/dev/null >/dev/null
        fi
        mount_point="$(find_crypto_mount_point $dst)"
        echo "CRYPTSETUP: mount $dst to $mount_point"
        mount "/dev/mapper/$dst" "$mount_point"
        rc=$?
        if [ $rc -ne 0 ];then
            echo "encrypt $dst fail"
            return $rc
        fi
	fi
    done < /etc/crypttab
    return $ret
}

if [ -f /etc/crypttab ]; then
    s="Starting disk encryption:"
    echo $s
    init_crypto 0
    ret=$?
    echo "Encryption reault $ret"
    if [ $ret -ne 0 ];then
        echo "[$s FAIL]"
    else
        echo "[$s OK]"
    fi
fi
