#!/bin/sh

/bin/vio_service
