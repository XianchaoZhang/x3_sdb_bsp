#!/bin/bash

echo "******************************"
echo "start processing root manifest $1"

function usage()
{
    echo "Error param, $0 $*"
    echo "Usage: $0 filename src_lp_dir src_hp_dir destdir"
    echo "       src_hp_dir will overwirte src_lp_dir"
}
if [ $# != 4 ];then
    usage
    exit 1
fi
if [ ! -f "$1" ];then
    usage
    exit 1
fi
if [ ! -d "$2" ];then
    echo "Error: $2 is not a valid directory"
    exit 1
fi
if [ ! -d "$3" ];then
    echo "Error: $3 is not a valid directory"
    exit 1
fi

# prepare directories
mkdir -p -m 555 sys proc
mkdir -p -m 1777 tftpboot
mkdir -p -m 755 dev bin sbin lib etc mnt usr/bin usr/sbin usr/lib home/root userdata app run tmp media
mkdir -p -m 755 var/volatile var/lib/urandom

f="$1"
d=$4
MANIFEST=".${f##*/}"

#rm -rf $d
mkdir -p $d
cd $d

# check manifest
sort -u $1 > $MANIFEST
sed -i 's/\\/\//g' $MANIFEST > /dev/null
sed -i '/^[[:space:]]*$/d' $MANIFEST > /dev/null
sed -i '/^[[:space:]]*[#]/d' $MANIFEST > /dev/null

echo "--- copy rootfs files start"

cat $MANIFEST | while read line;
do
    str=$line
    cmd="cp"
    param="-f"
    src_lp=$2/
    src_hp=$3/
    dst=$d/
    file_exists="true"
    subsrc=
    subdst=
    firstc="${str:0:1}"
    lastc="${str:0-1}"
    if [ "$firstc" = "-" ];then
        cmd="rm"
        param+="r"
        subdst="${str:1}"
        $cmd $param $dst$subdst
        echo "$cmd $param $dst$subdst"
        continue
    elif [ "$firstc" = "+" ];then
        param+="a"
        substr=${str:1}
        subsrc=$substr
    else
        echo "Invalid format: $str"
        exit 1
    fi

    if [ "$lastc" = "*" -o "$lastc" = "\/" ];then
        cp_all="true"
        subdst=${subsrc%/*}
        if [ -d "${subsrc%?}" ];then
            subsrc="${subdst}/."
        fi
    else
        if [ -L "$src$subsrc" ]; then
            subdst="${subsrc%/*}"
        elif [ -d "$src$subsrc" ]; then
            subdst="${subsrc}/"
            subsrc+="/."
        else
            subdst="${subsrc%/*}"
        fi
    fi
    stat $src_hp$subsrc &> /dev/null
    in_src_hp=$?
    stat $src_lp$subsrc &> /dev/null
    in_src_lp=$?
    if [ "$in_src_hp" = "0" ]; then
        src=$src_hp
    elif [ "$in_src_lp" = "0" ]; then
        src=$src_lp
    else
        file_exists="false"
    fi

    #echo "$src$subsrc stat is $retn"
    if [ $file_exists = "true" ];then
        if [ -L "$src$subsrc" ];then
            :
        elif [ -d "$src$subsrc" ];then
            if [ $(ls -a $src$subsrc| wc -l) == 2 ];then
                echo "$str is empty"
                #continue
            fi
        fi
    else
        echo "$str not exist"
        continue
    fi
    # echo "mkdir -p $dst$subdst"
    mkdir -p $dst$subdst
    # echo "$cmd $param $src$subsrc $dst$subdst"
    $cmd $param $src$subsrc $dst$subdst
    if [ "$cp_all" = "true" -a "$in_src_lp" = "0" ];then
        $cmd $param -n $src_lp$subsrc $dst$subdst
    fi
done

echo "--- end"

rm -rf $MANIFEST
echo "rm -rf $MANIFEST"

#dirname=$(dirname $4)
#basename=$(basename $4)
#cd $dirname
#echo "tar czf ${basename}.tar.gz $basename"
#tar czf ${basename}.tar.gz $basename
#(cd "$d"; find . | cpio -o -H newc | gzip) > ${basename}.cpio.gz

echo "end processing manifest $1"
echo "******************************"
