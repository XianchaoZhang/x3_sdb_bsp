This release package is used to test USB3 Electrical Compliance Test. The following script will force USB3 enter compliance mode and output compliance patterns.

How to use:
1. you may need to chnage mode by using "chmod 777 *"
2. cd /userdata/usb_verify
3. export PATH=$PWD/:$PATH: 
4.sh usb_enter_CP0.sh
5.sh usb_next_CP.sh


