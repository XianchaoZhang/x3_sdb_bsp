#ifndef EXCEPTION_HANDLING_H_
#define EXCEPTION_HANDLING_H_

int register_exception_signals(void);

#endif // EXCEPTION_HANDLING_H_

