# android win10 driver

- Download & Unzip attachment android_hobot_windriver.zip
- R-click "5-runasadmin_register-CA-cer.cmd" and "Run as administrator"*
- In Device Manager, expand "Ports (COM & LPT)", R-click "Serial USB device (COM3)" > Update Driver Software...
- Browse for my computer for driver software > Select extract folder

==================================================================================================================

hobot android 驱动安装 (fastboot, adb)

- 下载并解压 android_hobot_windriver.zip
- 右键点击"5-runasadmin_register-CA-cer.cmd", 以管理员身份运行
- xj3 设备插入后,  打开设备管理器, 如果设备未识别正确, 请右键点击改设备, 并更新驱动程序
- 浏览本地计算机, 选择解压的本文件夹, 更新即可