# how to build androidwinusb**.cat from android_winusb.inf & sign cat

Just refer to xxx.cmd in scripts. Copy them to above folder.
And run them one by one.
1-create_CA.cmd
2-make_pfx.cmd
3-build_cat.cmd
4-sign_cat.cmd

====
then righ click 5-runasadmin_register-CA-cer.cmd and Run as administrator

====
then you can update the driver in device manager