from netifaces import interfaces, ifaddresses, AF_INET


def get_local_ip_by_prefix(prefix):
    for ifn in interfaces():
        addr = [i['addr'] for i in ifaddresses(
            ifn).setdefault(AF_INET, [{'addr': 'No IP addr'}])]
        for a in addr:
            if a.startswith(prefix):
                return a
    return ''


def get_local_ip_all():
    addrs = []
    for ifn in interfaces():
        addr = [i['addr'] for i in ifaddresses(
            ifn).setdefault(AF_INET, [{'addr': 'No IP addr'}])]
        for a in addr:
            if a != 'No IP addr':
                addrs.append(a)
    return addrs


if __name__ == "__main__":
    print(get_local_ip_by_prefix("127.0.0."))
