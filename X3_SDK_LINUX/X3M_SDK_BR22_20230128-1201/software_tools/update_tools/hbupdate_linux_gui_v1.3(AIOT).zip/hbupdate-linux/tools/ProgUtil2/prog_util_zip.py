import zipfile
import getopt
import logging
import sys
import os
import shutil
import time
import configparser
from . import cli


VERSION = '1.0.3'
USAGE = '''
HB MCU re-programming utility.
Usage:
  prog_util_zip [options] [--type] [ZIP_FILE]
    eg1: --local=192.168.1.100 --remote=192.168.1.31 mcu.zip

Arguments:
  ZIP_FILE    zip file

Options:
  -h, --help          show help message.
  -v, --version       show version info.
  --local=            local IP address
  --remote=           remote IP address
  --verbose=          show debug info
        [debug, info, warn, error]
  --cmd=          		send command
        [update, reset, conn_reset]
'''

EXTRACT_DIR = 'input-copy'


def prog_util_zip(local_ip, remote_ip, unzip_folder):
    config = configparser.ConfigParser()
    try:
        config.read("ProgUtil.ini")
        wait_for_jump2pbl = int(
            config['Target']['TimeoutWaitForJump2Pbl'])
        wait_for_read_exit = int(
            config['Target']['TimeoutWaitForReadExit'])
        wait_for_jump2sbl = int(
            config['Target']['TimeoutWaitForJump2Sbl'])
    except:
        # logging.error(
        #     "Cannot read ProgUtil.ini file, use default value instead")
        wait_for_jump2pbl = 6000
        wait_for_read_exit = 5000
        wait_for_jump2sbl = 5000
    if wait_for_jump2pbl < 1000:
        wait_for_jump2pbl = 1000
    if wait_for_read_exit < 1000:
        wait_for_read_exit = 1000
    if wait_for_jump2sbl < 1000:
        wait_for_jump2sbl = 1000
    logging.info("Timeout value is J2PTO:{0}, RVTO:{1}, J2STO:{2}"
                 .format(wait_for_jump2pbl,
                         wait_for_read_exit, wait_for_jump2sbl))

    if unzip_folder:
        file_list = os.listdir(unzip_folder)
        for f in file_list:
            if f.lower().startswith('app_') and f.endswith('.bin'):
                app = os.path.join(unzip_folder, f)
            elif f.lower().startswith('sbl_') and f.endswith('.bin'):
                sbl = os.path.join(unzip_folder, f)

        if app is None or sbl is None:
            logging.error(
                "Cannot find App in zip file, start with app_, end with .bin")
            return 2
        else:
            if not cli.check_validity(app):
                return 2

        if sbl is None:
            logging.error(
                "Cannot find Sbl in zip file, start with sbl_, end with .bin")
            return 2
        else:
            if not cli.check_validity(sbl):
                return 2

        jok = cli.do_jump(ip=remote_ip, host_ip=local_ip)

        if jok:
            logging.info("Wait for {0} ms...".format(wait_for_jump2pbl))
            time.sleep(wait_for_jump2pbl/1000)
            sok = cli.do_prog(typea='sbl', app=sbl,
                              ip=remote_ip, host_ip=local_ip)
        else:
            sok = False
        if sok:
            logging.info("Wait for {0} ms...".format(wait_for_jump2sbl))
            time.sleep(wait_for_jump2sbl/1000)
            aok = cli.do_prog(typea='app', app=app,
                              ip=remote_ip, host_ip=local_ip)
        else:
            aok = False
        if aok:
            return 0
    return 1


EXTRACT_DIR = 'input-copy'

if __name__ == '__main__':
    local_ip = None
    remote_ip = None
    sbl = None
    app = None
    verbose = None
    cmd = None
    zfile = None

    try:
        opts, args = getopt.getopt(
            sys.argv[1:], "hv", ["help", "version", "type=", "local=",
                                 "remote=", "verbose="])
        for o, a in opts:
            if o in ("-h", "--help"):
                print(USAGE)
                sys.exit(0)
            elif o in ("-v", "--version"):
                print(VERSION)
                sys.exit(0)
            elif o in ("--type"):
                typea = a
            elif o in ("--local"):
                local_ip = a
            elif o in ("--remote"):
                remote_ip = a
            elif o in ("--port"):
                port = int(a)
            elif o in ("--verbose"):
                verbose = a
            elif o in ("--cmd"):
                cmd = a
        if len(args) == 1:
            zfile = args[0]
        if not remote_ip:
            print('ERROR: --remote must be provided')
            sys.exit(2)
        if not local_ip:
            local_ip = "0.0.0.0"
    except getopt.GetoptError:
        msg = sys.exc_info()[1]
        txt = 'ERROR: ' + str(msg)
        print(txt)
        print(USAGE)
        sys.exit(2)

    if not verbose:
        verbose = logging.INFO
    elif verbose == 'debug':
        verbose = logging.DEBUG
    elif verbose == 'error':
        verbose = logging.ERROR
    elif verbose == 'warn':
        verbose = logging.WARNING
    else:
        verbose = logging.INFO

    logger = logging.StreamHandler()

    logger.setFormatter(logging.Formatter(cli.LOG_FORMAT_MAP[verbose]))
    logging.getLogger().addHandler(logger)
    # You can control the logging level
    logging.getLogger().setLevel(verbose)
    logging.info("Version: {0}".format(VERSION))

    config = configparser.ConfigParser()
    try:
        config.read("ProgUtil.ini")
        wait_for_jump2pbl = int(
            config['Target']['TimeoutWaitForJump2Pbl'])
        wait_for_read_exit = int(
            config['Target']['TimeoutWaitForReadExit'])
        wait_for_jump2sbl = int(
            config['Target']['TimeoutWaitForJump2Sbl'])
    except:
        logging.error(
            "Cannot read ProgUtil.ini file, use default value instead")
        wait_for_jump2pbl = 6000
        wait_for_read_exit = 5000
        wait_for_jump2sbl = 5000
    if wait_for_jump2pbl < 1000:
        wait_for_jump2pbl = 1000
    if wait_for_read_exit < 1000:
        wait_for_read_exit = 1000
    if wait_for_jump2sbl < 1000:
        wait_for_jump2sbl = 1000
    logging.info("Timeout value is J2PTO:{0}, RVTO:{1}, J2STO:{2}"
                 .format(wait_for_jump2pbl,
                         wait_for_read_exit, wait_for_jump2sbl))

    with zipfile.ZipFile(zfile, "r") as zip_ref:
        shutil.rmtree(EXTRACT_DIR, ignore_errors=True)
        zip_ref.extractall(EXTRACT_DIR)
        file_list = os.listdir(EXTRACT_DIR)
        for f in file_list:
            if f.lower().startswith('app_') and f.endswith('.bin'):
                app = EXTRACT_DIR + os.path.sep + f
            elif f.lower().startswith('sbl_') and f.endswith('.bin'):
                sbl = EXTRACT_DIR + os.path.sep + f

        if app is None or sbl is None:
            logging.error(
                "Cannot find App in zip file, start with app_, end with .bin")
            sys.exit(2)
        else:
            if not cli.check_validity(app):
                sys.exit(2)

        if sbl is None:
            logging.error(
                "Cannot find Sbl in zip file, start with sbl_, end with .bin")
            sys.exit(2)
        else:
            if not cli.check_validity(sbl):
                sys.exit(2)

        jok = cli.do_jump(ip=remote_ip, host_ip=local_ip)

        if jok:
            logging.info("Wait for {0} ms...".format(wait_for_jump2pbl))
            time.sleep(wait_for_jump2pbl/1000)
            sok = cli.do_prog(typea='sbl', app=sbl,
                              ip=remote_ip, host_ip=local_ip)
        else:
            sok = False
        if sok:
            logging.info("Wait for {0} ms...".format(wait_for_jump2sbl))
            time.sleep(wait_for_jump2sbl/1000)
            aok = cli.do_prog(typea='app', app=app,
                              ip=remote_ip, host_ip=local_ip)
        else:
            aok = False
        if aok:
            sys.exit(0)
    sys.exit(1)
