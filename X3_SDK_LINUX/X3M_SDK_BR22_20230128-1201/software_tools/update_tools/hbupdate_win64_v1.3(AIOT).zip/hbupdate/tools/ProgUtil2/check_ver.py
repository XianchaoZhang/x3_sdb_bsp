import getopt
import logging
import sys
import os
import time
import socket
import datetime
from datetime import timedelta


VERSION = '1.0.0'
USAGE = '''
HB MCU check version.
Usage:
  check_ver [options]
    eg1: --local=192.168.1.100 --remote=192.168.1.31 --cmd=check --vfile=mcu-version.txt

Options:
  -h, --help          show help message.
  -v, --version       show version info.
  --local=            local IP address
  --remote=           remote IP address
  --verbose=          show debug info
        [debug, info, warn, error]
  --cmd=          		send command
        [check]
'''

LOG_FORMAT_MAP = dict()
LOG_FORMAT_MAP[logging.DEBUG] = '%(asctime)s - %(levelname)s - %(filename)s'\
    ' - %(lineno)d - %(message)s'
LOG_FORMAT_MAP[logging.INFO] = '%(levelname)s - %(message)s'
LOG_FORMAT_MAP[logging.WARNING] = '%(levelname)s - %(message)s'
LOG_FORMAT_MAP[logging.ERROR] = '%(levelname)s - %(message)s'


def connect(local, remote):
    tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp.settimeout(3)
    if tcp is not None:
        tcp.bind((local, 0))
        tcp.connect((remote, 8889))
    return tcp


def read_ver_file(f):
    ver = None
    try:
        with open(f, "r") as ver_file:
            ver = ver_file.readline().strip(' ')
    except Exception as e:
        logging.error("Read version file failed")
        logging.error(e)
    return ver


def read_ver(tcp):
    ver_did = 0xf181
    #pdu = struct.pack(PACK_FMT, sid_req, 0, 0, 0, ver_did)
    pdu = bytearray([0xfe, 0xdc, 0xba, 0x01, 0x02, 0x00, 0x06, 0x00, 0x00, 
                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x22, 0x00, 
                    0x00, 0x00, 0xf1, 0x81, 0x01, 0xba, 0xdc, 0xfe, ])
    _write(tcp, pdu)

    buf = bytearray(256)
    wait_until = datetime.datetime.now() + timedelta(seconds=6)
    while True:
        _read(tcp, buf, 20)
        length = buf[6] + buf[7] * 0xFF
        if length < 256:
            _read(tcp, buf, length)
            did = (buf[0] << 8) + buf[1]
            if did == ver_did:
                ver = buf[2:length-5]
                return ver.decode('utf-8').strip('\0 ')
        if wait_until > datetime.datetime.now():
            break
    return None


def disconnect(tcp):
    if tcp._closed is not False:
        tcp.shutdown()
    tcp.close()


def _write(tcp, payload):
    sent = None
    try:
        sent = tcp.send(payload)
    except socket.error as se:
        logging.error("Transmit failed because of socket exception!")
        for a in se.args:
            logging.error("{0}".format(a))
        disconnect(tcp)
        raise
    except:
        raise
    finally:
        pass
    return sent


def _read(tcp, buf, length):
    try:
        tcp.recv_into(buf, length)
    except socket.error as se:
        logging.error("Receive failed because of socket exception!")
        for a in se.args:
            logging.error("{0}".format(a))
        disconnect(tcp)
        raise
    except:
        raise
    finally:
        pass

def check_ver(local_ip, remote_ip, ver_file):
    if ver_file is None:
        logging.info(
            "INFO : Version file not provided, skip check process")
        return 0
    update_ver = read_ver_file(ver_file)
    tcp = connect(local_ip, remote_ip)
    if tcp:
        i = 0
        while (i < 5):
            curr_ver = read_ver(tcp)
            if curr_ver is not None:
                break
        disconnect(tcp)
        if update_ver is None:
            logging.error("Cannot read update version")
            return 3
        if curr_ver is None:
            logging.error("Cannot read board version")
            return 3
        logging.info("Board version {0}, to update to {1}".format(
            curr_ver, update_ver))
        if update_ver >= curr_ver:
            logging.info("Version check pass")
        else:
            logging.error("Version check failed")
            return 3
    else:
        logging.error("Socket bind or connect error")
        return 3
    return 0

if __name__ == '__main__':
    local_ip = None
    remote_ip = None
    verbose = None
    cmd = None
    ver_file = None
    try:
        opts, args = getopt.getopt(
            sys.argv[1:], "hv", ["help", "version", "cmd=", "local=",
                                 "remote=", "verbose=", "vfile="])
        for o, a in opts:
            if o in ("-h", "--help"):
                print(USAGE)
                sys.exit(0)
            elif o in ("-v", "--version"):
                print(VERSION)
                sys.exit(0)
            elif o in ("--local"):
                local_ip = a
            elif o in ("--remote"):
                remote_ip = a
            elif o in ("--port"):
                port = int(a)
            elif o in ("--verbose"):
                verbose = a
            elif o in ("--cmd"):
                cmd = a
            elif o in ("--vfile"):
                ver_file = a
        if not remote_ip:
            print('ERROR: --remote must be provided')
            sys.exit(2)
        if not cmd:
            print('ERROR: --cmd must be provided')
            sys.exit(2)
        if not local_ip:
            local_ip = "0.0.0.0"
    except getopt.GetoptError:
        msg = sys.exc_info()[1]
        txt = 'ERROR: ' + str(msg)
        print(txt)
        print(USAGE)
        sys.exit(2)

    if not verbose:
        verbose = logging.INFO
    elif verbose == 'debug':
        verbose = logging.DEBUG
    elif verbose == 'error':
        verbose = logging.ERROR
    elif verbose == 'warn':
        verbose = logging.WARNING
    else:
        verbose = logging.INFO

    logger = logging.StreamHandler()

    logger.setFormatter(logging.Formatter(LOG_FORMAT_MAP[verbose]))
    logging.getLogger().addHandler(logger)
    # You can control the logging level
    logging.getLogger().setLevel(verbose)
    logging.info("check-ver Version: {0}".format(VERSION))

    if cmd == 'check':
        sys.exit(check_ver(local_ip, remote_ip, ver_file))
    else:
        print('ERROR: --cmd={0} not supported' % cmd)
        sys.exit(2)

    sys.exit(0)
