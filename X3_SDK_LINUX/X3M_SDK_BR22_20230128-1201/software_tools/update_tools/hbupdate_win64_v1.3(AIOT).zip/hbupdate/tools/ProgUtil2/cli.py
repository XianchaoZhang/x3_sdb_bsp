#!/usr/bin/python3

import sys
import os
import logging
from . import prog_doip
import socket
import configparser
import getopt

SECTION_SIZE = 1024
PAGE_SIZE = 32
SBL_START = 0x60000000
APP_START = 0x80080000
PBL_START = 0x80000000

VERSION = '1.0.2'
USAGE = '''
HB MCU re-programming utility.
Usage:
  prog_util [options] [--type] [BIN_FILE]
    eg1: --type=sbl --port=13400 --ip=192.168.1.31 sbl.bin
    eg2: --port=13400 --ip=192.168.1.31 --cmd=update

Arguments:
  BIN_FILE    binary file

Options:
  -h, --help          show help message.
  -v, --version       show version info.
  --type              sbl/app.
  --port=             local port.
  --ip=               remote IP address
  --verbose=          show debug info
        [debug, info, warn, error]
  --cmd=          		send command
        [update, reset, conn_reset]
'''
LOG_FORMAT_MAP = dict()
LOG_FORMAT_MAP[logging.DEBUG] = '%(asctime)s - %(levelname)s - %(filename)s'\
    ' - %(lineno)d - %(message)s'
LOG_FORMAT_MAP[logging.INFO] = '%(levelname)s - %(message)s'
LOG_FORMAT_MAP[logging.WARNING] = '%(levelname)s - %(message)s'
LOG_FORMAT_MAP[logging.ERROR] = '%(levelname)s - %(message)s'


def check_validity(fn):
    retv = True
    zeros = 0
    # file exits
    if os.path.exists(fn):
        contents = prog_doip.load_bin_file(fn)
        # size is multiple of section size
        if (len(contents) % SECTION_SIZE) != 0:
            retv = False
        # first page (32 bytes) is not all zeros.
        for i in range(0, PAGE_SIZE):
            if contents[i] == 0:
                zeros += 1
        if zeros == PAGE_SIZE:
            logging.error('First 32 bytes are all zeros.')
            retv = False
    else:
        logging.error('{0} not exits.'.format(fn))
        retv = False
    return retv


def get_session(typea):
    if (typea == 'sbl'):
        start = SBL_START
        session_jump = 0x00
        session_ok = 0x61
        session_nok = 0x02
    elif (typea == 'app'):
        start = APP_START
        session_jump = 0x00
        session_ok = 0x01
        session_nok = 0x61
    else:
        return None, None, None, None
    return start, session_jump, session_ok, session_nok


def process_cmd(ph, cmd):
    retv = None
    if cmd == 'update':
        if ph.is_closed():
            ph.open()
            try:
                ph.connect(ip)
                logging.info("Connected")
                if typea == 'sbl':
                    logging.info("Jump to programming session...")
                    ok = ph.prog_cmd_request_to_update()
                if ok:
                    logging.info("Jump to rogramming session succeed")
                else:
                    logging.info("Jump to rogramming session failed")
            except Exception as e:
                logging.error("Jump failed because of socket exception")
                for a in e.args:
                    logging.error("{0}".format(a))
            finally:
                ph.shutdown()
                ph.close()
    elif cmd == 'reset':
        print(USAGE)
        sys.exit(1)
    elif cmd == 'conn_reset':
        print(USAGE)
        sys.exit(1)
    return retv


if __name__ == '__main__':
    typea = None
    port = None
    ip = None
    app = None
    verbose = None
    cmd = None
    host_ip = None

    try:
        opts, args = getopt.getopt(
            sys.argv[1:], "hv", ["help", "version", "type=", "port=", "local=",
                                 "remote=", "verbose=", "cmd="])
        for o, a in opts:
            if o in ("-h", "--help"):
                print(USAGE)
                sys.exit(0)
            elif o in ("-v", "--version"):
                print(VERSION)
                sys.exit(0)
            elif o in ("--type"):
                typea = a
            elif o in ("--local"):
                ip = a
            elif o in ("--remote"):
                host_ip = a
            elif o in ("--port"):
                port = int(a)
            elif o in ("--verbose"):
                verbose = a
            elif o in ("--cmd"):
                cmd = a

        if cmd:
            if cmd not in ("update", "reset", "conn_reset"):
                print('ERROR: unsupported command {0}'.format(cmd))
                sys.exit(2)
        else:
            if not typea:
                print('ERROR: --type or --cmd must be provided')
                sys.exit(2)
            if len(args) == 1:
                app = args[0]
            else:
                print('ERROR: One and only one application binary file')
                sys.exit(2)

        if not ip:
            print('ERROR: --ip must be provided')
            sys.exit(2)

        if not port:
            port = 0

    except getopt.GetoptError:
        msg = sys.exc_info()[1]
        txt = 'ERROR: ' + str(msg)
        print(txt)
        print(USAGE)
        sys.exit(2)

    if not verbose:
        verbose = logging.INFO
    elif verbose == 'debug':
        verbose = logging.DEBUG
    elif verbose == 'error':
        verbose = logging.ERROR
    elif verbose == 'warn':
        verbose = logging.WARNING
    else:
        verbose = logging.INFO

    logger = logging.StreamHandler()
    logger.setFormatter(logging.Formatter(LOG_FORMAT_MAP[verbose]))
    logging.getLogger().addHandler(logger)
    # You can control the logging level
    logging.getLogger().setLevel(verbose)
    ok = False
    ph = prog_doip.ProgDoIP(host_ip, port)
    if cmd:
        process_cmd(ph, cmd)
    else:
        if (typea == 'sbl'):
            pass
        elif (typea == 'app'):
            pass
        else:
            print(USAGE)
            sys.exit(2)

        if not check_validity(app):
            sys.exit(2)

        ok = do_prog(typea, app, ip)
    if ok:
        sys.exit(0)
    sys.exit(1)


def do_jump(ip, host_ip=None, port=0, typea='sbl'):
    ph = prog_doip.ProgDoIP(host_ip, port)
    ok = False
    if ph.is_closed():
        ph.open()
        try:
            ph.connect(ip)
            logging.info("Connected")
            if typea == 'sbl':
                logging.info("Jump to programming session...")
                ok = ph.prog_cmd_request_to_update()
            if ok:
                logging.info("Jump to rogramming session succeed")
            else:
                logging.info("Jump to rogramming session failed")
        except Exception as e:
            logging.error("Jump failed because of socket exception")
            for a in e.args:
                logging.error("{0}".format(a))
        finally:
            ph.shutdown()
            ph.close()
    return ok


def do_prog(typea, app, ip, host_ip=None, port=0, bar=None):
    ph = prog_doip.ProgDoIP(host_ip, port)
    start, session_jump, session_ok, session_nok = get_session(typea)
    ph.set_process(typea, session_jump, session_ok, session_nok)
    content = prog_doip.load_bin_file(app)
    ok = False
    if ph.is_closed():
        ph.open()
        try:
            ph.connect(ip)
            logging.info("Connected")
            if (typea == 'sbl'):
                do_read_partnumber(ph, 'pbl')
            elif (typea == 'app'):
                do_read_partnumber(ph, 'sbl')
            ok = ph.flash(
                content, start, progbar=bar)
            if ok:
                logging.info("Flash {0} succeed".format(typea))
            else:
                logging.error("Flash {0} failed".format(typea))
        except Exception as e:
            logging.error(
                "Flash {0} failed because of socket exception".format(typea))
            for a in e.args:
                logging.error("{0}".format(a))
        finally:
            ph.shutdown()
            ph.close()
    return ok


def do_read_partnumber(ph, session_type):
    if session_type == 'pbl':
        logging.info("Read Part Numbers...")
        hw_ver = ph.read_did(0xF192)
        if len(hw_ver) == 0:
            hw_ver = "N.A."
        else:
            hw_ver = hw_ver.decode('utf-8')
        sw_ver = ph.read_did(0xF180)
        if len(sw_ver) == 0:
            sw_ver = "N.A."
        else:
            sw_ver = sw_ver.decode('utf-8')
        logging.info(
            "PBL hardware version {0}".format(hw_ver))
        logging.info(
            "PBL software version {0}".format(sw_ver))
    elif session_type == 'sbl':
        logging.info("Read Part Numbers...")
        hw_ver = ph.read_did(0xF193)
        if len(hw_ver) == 0:
            hw_ver = "N.A."
        else:
            hw_ver = hw_ver.decode('utf-8')
        sw_ver = ph.read_did(0xF181)
        if len(sw_ver) == 0:
            sw_ver = "N.A."
        else:
            sw_ver = sw_ver.decode('utf-8')
        logging.info(
            "SBL hardware version {0}".format(hw_ver))
        logging.info(
            "SBL software version {0}".format(sw_ver))
