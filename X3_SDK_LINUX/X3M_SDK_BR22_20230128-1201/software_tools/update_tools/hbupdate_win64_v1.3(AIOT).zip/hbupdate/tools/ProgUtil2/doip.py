import socket
import logging
import struct

TCP_HANDLER = None
REMOTE_PORT = 13400

DOIP_PROTOCOL_HEADER_LENGTH = 8
DOIP_PROTOCOL_VER = 0x02
DOIP_PROTOCOL_INVERSE_VER = 0xFD

DOIP_PAYLOAD_TYPE_GENERIC_DOIP_HEADER_NEGATIVE_ACKNOWLEDGE = 0X0000
DOIP_PAYLOAD_TYPE_VEHICLE_IDENTIFICATION_REQUEST_MESSAGE = 0X0001
DOIP_PAYLOAD_TYPE_VEHICLE_IDENTIFICATION_REQUEST_MESSAGE_WITH_EID = 0X0002
DOIP_PAYLOAD_TYPE_VEHICLE_IDENTIFICATION_REQUEST_MESSAGE_WITH_VIN = 0X0003
DOIP_PAYLOAD_TYPE_ROUTING_ACTIVATION_REQUEST = 0X0005
DOIP_PAYLOAD_TYPE_ROUTING_ACTIVATION_RESPONSE = 0X0006
DOIP_PAYLOAD_TYPE_ALIVE_CHECK_REQUEST = 0X0007
DOIP_PAYLOAD_TYPE_ALIVE_CHECK_RESPONSE = 0X0008

DOIP_PAYLOAD_TYPE_DOIP_ENTITY_STATUS_REQUEST = 0X4001
DOIP_PAYLOAD_TYPE_DOIP_ENTITY_STATUS_RESPONSE = 0X4002
DOIP_PAYLOAD_TYPE_DIAGNOSTIC_POWER_MODE_INFORMATION_REQUEST = 0X4003
DOIP_PAYLOAD_TYPE_DIAGNOSTIC_POWER_MODE_INFORMATION_RESPONSE = 0X4004

DOIP_PAYLOAD_TYPE_DIAGNOSTIC_MESSAGE = 0X8001
DOIP_PAYLOAD_TYPE_DIAGNOSTIC_MESSAGE_POSITIVE_ACKNOWLEDGEMENT = 0X8002
DOIP_PAYLOAD_TYPE_DIAGNOSTIC_MESSAGE_NEGATIVE_ACKNOWLEDGEMENT = 0X8003

DOIP_HEADER_PACK_FMT = "!BBHI{0}s"
DOIP_HEADER_UNPACK_FMT = "!BBHI"

DOIP_DEFAULT_TIMEOUT = 3
DOIP_CONNECT_TIMEOUT = 3


class DoIP(object):
    def __init__(self, loglevel=logging.DEBUG):
        self._tcp = None
        self._tcp = None
        self._is_closed = True

    def open(self, local, port):
        self._tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # TODO xiao.chen: check implicit binding
        if local is None:
            return
        logging.info("Binding to {0}:{1}".format(local, port))
        self._tcp.bind((local, port))

    def connect(self, remote):
        logging.info("Connecting to {0}".format(remote))
        try:
            self._tcp.settimeout(DOIP_CONNECT_TIMEOUT)
            self._tcp.connect((remote, REMOTE_PORT))
            self._is_closed = False
        except socket.error as e:
            if e.errno == 10056:
                # A connect request was made on an already connected socket
                self.close()
                self._tcp.connect((remote, REMOTE_PORT))
            raise
        except:
            raise

    def shutdown(self):
        try:
            self._tcp.shutdown(socket.SHUT_RDWR)
            self._is_closed = True
            logging.info("Shut down tcp")
        except Exception:
            pass

    def close(self):
        if self._tcp._closed is not False:
            self.shutdown()
        self._tcp.close()
        logging.info("Close tcp")
        self._tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def is_empty(self):
        return self._tcp

    def is_closed(self):
        return self._is_closed or self._tcp._closed

    def diag_request(self, payload):
        pdu = struct.pack(DOIP_HEADER_PACK_FMT.format(len(payload)),
                          DOIP_PROTOCOL_VER, DOIP_PROTOCOL_INVERSE_VER,
                          DOIP_PAYLOAD_TYPE_DIAGNOSTIC_MESSAGE,
                          len(payload) & 0xFFFFFFFF, payload)
        return self._write(pdu)

    def wait_for_response(self, timeout=DOIP_DEFAULT_TIMEOUT):
        if timeout != DOIP_DEFAULT_TIMEOUT:
            self._tcp.settimeout(timeout)
        buf = bytearray(DOIP_PROTOCOL_HEADER_LENGTH)
        self._read(buf, len(buf))
        ver, inv, t, length = struct.unpack(DOIP_HEADER_UNPACK_FMT, buf)
        if (ver == DOIP_PROTOCOL_VER) and \
            (inv == DOIP_PROTOCOL_INVERSE_VER) and \
                (t == DOIP_PAYLOAD_TYPE_DIAGNOSTIC_MESSAGE) and (length >= 1):
            sdu = bytearray(length)
            self._read(sdu, length)
            return sdu
        return None

    def _write(self, payload):
        sent = None
        try:
            sent = self._tcp.send(payload)
        except socket.error as se:
            logging.error("DoIP transmit failed because of socket exception!")
            for a in se.args:
                logging.error("{0}".format(a))
            self.close()
            raise
        except:
            raise
        finally:
            pass
        return sent

    def _read(self, buf, length):
        try:
            self._tcp.recv_into(buf, length)
        except socket.error as se:
            logging.error("DoIP receive failed because of socket exception!")
            for a in se.args:
                logging.error("{0}".format(a))
            self.close()
            raise
        except:
            raise
        finally:
            pass
