import logging
import os
import binascii

from struct import unpack
from time import sleep, time

import intelhex as IH
from . import doip


def load_bin_file(name):
    ih = IH.IntelHex()
    ih.loadbin(name)
    return ih.tobinarray()


def bytes_to_int32(data: bytes, big_endian=True) -> int:
    if len(data) != 4:
        raise ValueError("int32 should be exactly 4 bytes")
    if big_endian:
        return unpack('>I', data)[0]
    else:
        return unpack('<I', data)[0]


class ProgDoIP(object):
    def __init__(self, local, port):
        self._doip = None
        self._target = None
        self._target_session = None
        self._target_ok_session = None
        self._target_nok_session = None
        self._prog_seq_cnt_total = None
        self._prog_seq_cnt = None
        self._host_ip = local
        self._host_port = port
        self._doip = doip.DoIP()

    def open(self):
        self._doip.open(self._host_ip, self._host_port)

    def connect(self, remote):
        self._doip.connect(remote)

    def shutdown(self):
        self._doip.shutdown()

    def close(self):
        self._doip.close()

    def is_closed(self):
        return self._doip.is_closed()

    def set_process(self, target, session, ok_session, nok_session):
        self._target = target
        self._target_session = session
        self._target_ok_session = ok_session
        self._target_nok_session = nok_session

    @staticmethod
    def _check_response(resp, sid, length, arg=None):
        if resp is None:
            logging.error("Response timeout for {0:X}".format(sid))
            return False
        if len(resp) != length:
            logging.error(
                "Response length incorrect, expected {0}, received {1}"
                .format(length, len(resp)))
            return False

        if sid != resp[0]:
            logging.error(
                "Response service id incorrect, expected {0}, received {1}"
                .format(sid, resp[0]))
            return False

        if ((length > 1) and (arg is not None) and (arg != resp[1])):
            logging.error(
                "Response service argument incorrect, \
                    expected {0}, received {1}"
                .format(arg, resp[1]))
            return False
        return True

    def flash(self, content, start, progbar=None, bs=1024):
        is_continued = False
        is_back_to_app = False

        if self._target is None:
            logging.error("No valid target file")
            return False
        if self._doip is None:
            logging.error("No valid DoIP handler")
            return False
        if self._doip.is_closed():
            logging.error("No connected DoIP handler")
            return False
        if len(content) % bs != 0:
            logging.error(
                "Size of content mismatch with block size {0}".format(bs))
            return False

        session = self._target_session
        if session != 0:
            logging.info("Request to enter session 0x{0:x}".format(session))
            if session == 2:
                self._cmd_request_to_programming(session)
            else:
                is_continued = self._uds_diag_session_ctrl(session)
        else:
            is_continued = True
            sleep(0.2)

        if (is_continued) and (progbar is not None):
            progbar(1)
        else:
            logging.info("Progress: {0}%".format(1))

        if is_continued:
            is_continued = False
            logging.info(
                "Request to download start at 0x{0:X}, size {1}"
                .format(start, len(content)))
            is_continued = self._uds_request_transmit(start, len(content))

        if (is_continued) and (progbar is not None):
            progbar(2)
        else:
            logging.info("Progress: {0}%".format(2))

        if is_continued:
            is_continued = False
            # currently, only support multiple of 1024 bytes.
            total_seq_cnt = int(len(content) / 1024)
            if total_seq_cnt > 0xFFFF:
                logging.warning(
                    "Blocks exceeds 0xFFFF. \
                        Only a count value within 2 bytes can be verified")
            logging.info("Transfering...")
            logging.info("Total number of blocks {0}".format(total_seq_cnt))
            for i in range(0, total_seq_cnt):
                is_continued = self._uds_transfer_data(
                    content[i * 1024:], 1024)
                if not is_continued:
                    logging.error(
                        "Transfer data error at block {0}".format(i + 1))
                    break
                if progbar is not None:
                    progbar(((i + 1) / total_seq_cnt) * 95 + 3)
                else:
                    print("Progress: {0:.2%}".format(
                        (i + 1) / total_seq_cnt), end='\r')

        if (is_continued) and (progbar is not None):
            progbar(98)
        else:
            logging.info("Progress: {0}%".format(98))

        prog_ok = False
        if is_continued:
            is_continued = False
            logging.info("Request to exit transfer")
            prog_ok = self._uds_transfer_exit(2)

        if (prog_ok) and (progbar is not None):
            progbar(99)
        else:
            logging.info("Progress: {0}%".format(99))

        session = self._target_nok_session
        if prog_ok:
            session = self._target_ok_session
            logging.info("Re-programming succeed")
        else:
            logging.error("Re-programming failed")

        is_back_to_app = self._uds_diag_session_ctrl(session)
        if not is_back_to_app:
            logging.error("Failed to jump to session 0x{0:X}".format(session))
        else:
            logging.info("Jumped to session 0x{0:X}".format(session))

        if prog_ok and is_back_to_app:
            if progbar is not None:
                progbar(100)
            else:
                logging.info("Progress: {0}%".format(100))
        return prog_ok and is_back_to_app

    def _uds_request_transmit(self, start, length):
        payload = [0x34, 0x00, 0x44]
        payload.extend(start.to_bytes(4, 'big'))
        payload.extend(length.to_bytes(4, 'big'))
        logging.info("UDS: request to transmit {0}".format(
            binascii.hexlify(bytes(payload))))
        self._doip.diag_request(payload=bytearray(payload))
        self._prog_seq_cnt_total = 0
        self._prog_seq_cnt = 0
        is_continued = False
        frm = self._wait_for_frames()
        if frm is not None:
            logging.info("Request transmit response {0}".format(
                binascii.hexlify(frm)))
            expected = [0x74, 0x40, 0x00, 0x00, 0x01, 0x00]
            if frm == bytes(expected):
                is_continued = True
        return is_continued

    def _uds_transfer_data(self, buf, length):
        self._prog_seq_cnt += 1
        self._prog_seq_cnt_total += 1
        if self._prog_seq_cnt > 255:
            self._prog_seq_cnt = 0
        payload = [0x36, self._prog_seq_cnt]
        for i in range(length):
            payload.append(buf[i])
        self._doip.diag_request(payload=bytearray(payload))
        is_continued = False
        frm = self._wait_for_frames()
        if frm is not None:
            if frm[0] == 0x76:
                is_continued = True
            else:
                logging.error(
                    "Tranfer data error at block {0}, start from 1"
                    .format(i + 1))
                is_continued = False
        return is_continued

    def _uds_transfer_exit(self, cnt):
        payload = [0x37]
        payload.extend(self._prog_seq_cnt_total.to_bytes(2, 'big'))
        payload.extend([0xA1, 0xA2, 0xA3, 0xA4])
        self._doip.diag_request(payload=bytearray(payload))
        prog_ok = False
        frm = self._wait_for_frames()
        if frm is not None:
            logging.info("Transfer exit response {0}".format(
                binascii.hexlify(frm)))
            if frm[0] == 0x77:
                prog_ok = True
            elif ((frm[0] == 0x7F) and (frm[1] == 0x37)):
                prog_ok = False
        return prog_ok

    def _uds_diag_session_ctrl(self, session):
        is_continued = False
        payload = [0x10, session]
        self._doip.diag_request(payload=bytearray(payload))
        frm = self._wait_for_frames()
        if frm is not None:
            logging.debug("Session control response {0}".format(
                binascii.hexlify(frm)))
            if ProgDoIP._check_response(frm, 0x50, 6, session):
                is_continued = True
            else:
                logging.error("Request to enter session negative response {0}"
                              .format(binascii.hexlify(frm)))
        return is_continued

    def _cmd_request_to_programming(self, session):
        payload = [0x10, session]
        self._doip.diag_request(payload=bytearray(payload))

    def _cmd_request_to_reset(self, typea):
        payload = [0x11, typea]
        self._doip.diag_request(payload=bytearray(payload))

    def _wait_for_frames(self):
        resp = self._doip.wait_for_response()
        if resp is None:
            logging.error("No valid response.")
        return resp

    def prog_cmd_request_to_update(self):
        retv = False
        session = 0x02
        logging.info(
            "CMD: request update by enter session 0x{0:x}".format(session))
        self._cmd_request_to_programming(session)
        frm = self._wait_for_frames()
        if frm is not None:
            logging.info("CMD: request update response {0}".format(
                binascii.hexlify(frm)))
            if frm[0] == 0x50 and frm[1] == session:
                retv = True
        return retv

    def prog_cmd_request_to_reset(self):
        retv = False
        session = 0x02
        logging.info("CMD: request reset {0:x}".format(session))
        self._cmd_request_to_reset(session)
        frm = self._wait_for_frames()
        if frm is not None:
            logging.info("CMD: request reset response {0}".format(
                binascii.hexlify(frm)))
            if frm[0] == 0x51 and frm[1] == session:
                retv = True
        return retv

    def read_did(self, did):
        dh = (did >> 8) & 0xFF
        dl = did & 0xFF
        payload = [0x22, dh, dl]
        self._doip.diag_request(payload=bytearray(payload))
        frm = self._wait_for_frames()
        if frm is None or len(frm) < 3:
            logging.error(
                "UDS: Read DID {0} with response less than 3".format(did))
        else:
            if frm[0] == 0x62 and frm[1] == dh and frm[2] == dl:
                return frm[3:]
            else:
                logging.info("UDS: Read DID {0} with response {0}".format(
                    binascii.hexlify(frm)))
        return []
