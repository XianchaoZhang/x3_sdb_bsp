from optparse import OptionParser
import serial
import xmodem
import os
import sys
import time
import logging
import pyprind
from binascii import b2a_hex, a2b_hex
from spi import *
from spi_h import *
from serial.serialutil import SerialBase, SerialException, to_bytes, \
    portNotOpenError, writeTimeoutError, Timeout


class XmodemDownload:
    def __init__(self, ):
        self.spi = FT4222_spi_master()
        self.error = ''
        ret = self.spi.get_handle()
        if not ret:
            self.spi.deinit()
            self.error = "get_handle wrong!!!"
            logging.error(self.error)
            return False
        ret = self.spi.master_init(SYS_CLK_24, CLK_DIV_256, CLK_IDLE_LOW, CLK_LEADING, DS_16MA)
        if not ret:
            self.spi.deinit()
            self.error = "master_init wrong!!!"
            logging.error(self.error)
            return False

    def getc(self, size, timeout=1):
        return self.s.read(size)

    def putc(self, data, timeout=1):
        self.bar_user.update()
        return self.s.write(data)

    def spi_getc(self, size, timeout=1):
        tmp = [0 for x in range(0, size)]

        start_time = int(time.time())
        while (int(time.time()) - start_time) < timeout:
            sizeTransferred, data_r = self.spi.master_readwrite(bytes(tmp), size)
            if sizeTransferred == 1 and len(data_r) != 0:
                break
            else:
                data_r = '0'
        #  print(data_r)
        return data_r

    def spi_putc(self, data, timeout=1):
        #  print("send: ", data)
        #  self.bar_user.update()
        sizeTransferred, data_r = self.spi.master_readwrite(to_bytes(data), len(data))

    def spi_transfer(self, src_file, dst_file='', timeout=1, pcb_cfg=None):
        with open(src_file, 'rb') as stream:
            if not stream:
                self.spi.deinit()
                self.error = 'file is empty'
                logging.error(self.error)
                return False

            # set progress bar display
            statinfo_bin = os.stat(src_file)
            self.bar_user = pyprind.ProgBar(statinfo_bin.st_size/1024+2)

            #  m = xmodem.XMODEM(self.spi_getc, self.spi_putc)
            m = xmodem.XMODEM(self.spi_getc, self.spi_putc, "xmodem1k")
            start_time = (time.time())
            ret = m.send(stream)
            end = (time.time())
            print("time: ", end - start_time)
            if ret is False:
                print("----------SPI Xmodem error\n")
            return ret

    def uart_transfer(self, src_file, dst_file='', timeout=1, pcb_cfg=None):
        with open(src_file, 'rb') as stream:
            if not stream:
                self.error = 'file is empty'
                logging.error(self.error)
                return False

            # set progress bar display
            statinfo_bin = os.stat(src_file)
            self.bar_user = pyprind.ProgBar(statinfo_bin.st_size/1024+2)

            self.s = serial.Serial('/dev/ttyS0', timeout=0.1, baudrate=57600)

            m = xmodem.XMODEM(self.getc, self.putc, "xmodem1k")
            start_time = (time.time())
            m.send(stream)
            end = (time.time())
            print("time: ", end - start_time)

            # finish, close the port
            self.s.flush()
            self.s.flushInput()
            self.s.close()


if __name__ == '__main__':
    file_name = sys.argv[1]
    download = XmodemDownload()
    print(file_name)

    ok_num = 0
    error_num = 0

    while 1:
        ret = download.spi_transfer(file_name)
        if ret is False:
            error_num += 1
        else:
            ok_num += 1
        print("error_num: ", error_num, "ok_num: ", ok_num)
        time.sleep(3)
    # download.uart_transfer(file_name)
