import binascii
import sys
from spi import *
from spi_h import *
import serial
import xmodem
import pyprind


class spi_master:
    def __init__(self, ):
        self.spi = FT4222_spi_master()
        self.error = ''

    def init(self):
        return True

    def check_connection(self):
        info = self.spi.get_dev_info()
        if info:
            return True
        return False

    def big2little(self, data, len):
        tmp = data.to_bytes(len, byteorder='big')
        return int.from_bytes(tmp, byteorder='little', signed=False)

    def transfer_push(self, src_file, dst_file='', timeout=1, pcb_cfg=None):
        """
        upload local file to remote with SFTP protocol
        """
        try:
            with open(src_file, 'rb') as stream:
                if not stream:
                    self.deinit()
                    self.error = 'file is empty'
                    logging.error(self.error)
                    return False
                ret = self.spi.get_handle()
                if not ret:
                    self.deinit()
                    self.error = "get_handle wrong!!!"
                    logging.error(self.error)
                    return False
                ret = self.spi.master_init(SYS_CLK_24, CLK_DIV_256, CLK_IDLE_LOW, CLK_LEADING, DS_16MA)
                if not ret:
                    self.deinit()
                    self.error = "master_init wrong!!!"
                    logging.error(self.error)
                    return False

                print("--start SPI_CMD_SYNC--")
                ret, respon = self.spi.spi_cmd(SPI_CMD_SYNC, 0, 0, 1)
                if not ret:
                    self.deinit()
                    self.error = "SPI_CMD_SYNC wrong!!!"
                    logging.error(self.error)
                    return False
                print("--stop SPI_CMD_SYNC--")
                data = stream.read()
                data_len = len(data)
                print("data_len = %#x" % data_len)
                print("--start SPI_CMD_SEND_LEN--")
                ret, respon = self.spi.spi_cmd(SPI_CMD_SEND_LEN, self.big2little(data_len, 4), 4, 2)
                if not ret:
                    self.deinit()
                    self.error = "SPI_CMD_SEND_LEN wrong!!!"
                    logging.error(self.error)
                    return False
                print("--stop SPI_CMD_SEND_LEN--")
                time.sleep(1)
                print("--start SPI_CMD_GET_LEN--")
                ret, respon = self.spi.spi_cmd(SPI_CMD_GET_LEN, 0, 1, 2)
                if not ret or respon != b'\x01':
                    self.deinit()
                    self.error = "SPI_CMD_GET_LEN wrong!!!"
                    logging.error(self.error)
                    return False
                print("--stop SPI_CMD_GET_LEN--")
                check_sum = 0
                for i in range(data_len):
                    check_sum += data[i]
                print("checksum = %#x" % check_sum)
                print("--start SPI_CMD_SEND_CHECKSUM--")
                ret, respon = self.spi.spi_cmd(SPI_CMD_SEND_CHECKSUM, self.big2little(check_sum, 4), 4, 2)
                if not ret:
                    self.deinit()
                    self.error = "SPI_CMD_SEND_CHECKSUM wrong!!!"
                    logging.error(self.error)
                    return False
                print("--stop SPI_CMD_SEND_CHECKSUM--")
                print("--start SPI_CMD_SEND_DATA--")
                time.sleep(1)
                ret, respon = self.spi.spi_cmd(SPI_CMD_SEND_DATA, data, data_len, 2)
                if not ret:
                    self.deinit()
                    self.error = "SPI_CMD_SEND_DATA wrong!!!"
                    logging.error(self.error)
                    return False
                print("--stop SPI_CMD_SEND_DATA--")
                print("--start SPI_CMD_GET_CHECKSUM--")
                ret, respon = self.spi.spi_cmd(SPI_CMD_GET_CHECKSUM, 0, 1, 2)
                if not ret or respon == b'\xa5':
                    self.deinit()
                    self.error = "SPI_CMD_GET_CHECKSUM wrong!!!"
                    logging.error(self.error)
                    return False
                print("--stop SPI_CMD_GET_CHECKSUM--")
        except Exception as err:
            self.deinit()
            self.error = err
            logging.error(self.error)
            return False, self.error
        return True, 0

    def deinit(self):
        self.spi.deinit()
        return True

if __name__ == '__main__':
    file_name = sys.argv[1]
    test_spi = spi_master()
    print(file_name)
    test_spi.transfer_push(file_name)
