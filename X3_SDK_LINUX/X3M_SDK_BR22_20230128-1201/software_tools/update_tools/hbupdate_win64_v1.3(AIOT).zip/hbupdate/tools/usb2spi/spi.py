import os
import time
import logging
import sys
import platform
from ctypes import *
from spi_h import *

SPI_CMD_SYNC = b'\x50'
SPI_CMD_SEND_LEN = b'\x51'
SPI_CMD_GET_LEN = b'\x52'
SPI_CMD_SEND_CHECKSUM = b'\x53'
SPI_CMD_SEND_DATA = b'\x54'
SPI_CMD_GET_CHECKSUM = b'\x55'


class FT4222_spi_master():
    def __init__(self):
        self.error = ""
        self.lib_opened = False
        self.ft_lib = None
        self.dev_lib = None
        self.ft_handle = FT_HANDLE()
        self.platform = platform.system()
        self.dev_num = 0
        self.max_size = 16384

    def open_lib(self):
        if self.lib_opened:
            return True
        if self.platform == 'Windows':
            self.ft_lib = windll.LoadLibrary('./ftd2xx.dll')
            if not self.ft_lib:
                self.error = "Can not open ftd2xx.dll: status = %d" % self.ft_lib
                logging.error(self.error)
                return False
            self.dev_lib = cdll.LoadLibrary('./LibFT4222.dll')
            if not self.dev_lib:
                self.error = "Can not open LibFT4222.dll: status = %d" % self.dev_lib
                logging.error(self.error)
                return False
        # elif self.platform == 'Darwin':
        #    pass
        elif self.platform == 'Linux':
            self.ft_lib = cdll.LoadLibrary('./libft4222.so.1.4.4.9')
            # self.ft_lib = cdll.LoadLibrary('./libftd2xx.so.1.4.8')
            print(self.ft_lib)
            if not self.ft_lib:
                self.error = "Can not open libft4222.so: status = %d" % self.ft_lib
                logging.error(self.error)
                return False
            self.dev_lib = self.ft_lib
            '''
            self.dev_lib = cdll.LoadLibrary('./libft4222.so.1.4.4.9')
            print(self.dev_lib)
            if not self.dev_lib:
                self.error = "Can not open libft4222.so.1.4.4.9 status = %d" % self.dev_lib
                logging.error(self.error)
                return False
            '''
        else:
            self.error = "system not suport"
            return False
        self.lib_opened = True
        return True

    def getDeviceInfoDetail(self, devnum=0):
        """Get an entry from the internal device info list. Set update to
        False to avoid a slow call to createDeviceInfoList."""
        f = DWORD()
        t = DWORD()
        i = DWORD()
        l = DWORD()
        h = FT_HANDLE()
        n = c_buffer(16)
        d = c_buffer(64)
        status = self.ft_lib.FT_GetDeviceInfoDetail(DWORD(devnum), byref(f), byref(t), byref(i), byref(l), n, d, byref(h))
        if status:
            return None
        return {'index': devnum, 'flags': f.value, 'type': t.value,
                'id': i.value, 'location': l.value, 'serial': n.value,
                'description': d.value, 'handle': h}

    def get_dev_info(self):
        dev_num = DWORD(0)
        status = self.ft_lib.FT_CreateDeviceInfoList(byref(dev_num))
        if status:
            self.error = "Can not get devices number: status = %d" % status
            logging.error(self.error)
            return None
        if dev_num.value == 0:
            self.error = "no FT4222 devices"
            logging.error(self.error)
            return None
        self.dev_num = dev_num.value
        print(self.dev_num)
        info = list()
        for i in range(self.dev_num):
            time.sleep(0.01)
            info.append(self.getDeviceInfoDetail(i))
        if not info:
            self.error = "Can not get devices information: status = %d" % info
            logging.error(self.error)
            return None
        print(info)
        return info

    def get_handle(self, locaid=0):
        if locaid:
            LocId = DWORD(locaid)
        else:
            ret = self.open_lib()
            if not ret:
                return False
            info = self.get_dev_info()
            if info:
                LocId = DWORD(info[0]['location'])
            else:
                return False
        self.ft_lib.FT_OpenEx.restype = FT_STATUS
        self.ft_lib.FT_OpenEx.argtypes = [DWORD, DWORD, POINTER(FT_HANDLE)]
        status = self.ft_lib.FT_OpenEx(LocId, DWORD(4), byref(self.ft_handle))
        if status:
            self.error = "Can not get ft handle: status = %d" % status
            logging.error(self.error)
            return False
        return True

    def master_init(self, sys_clk, div_clk, cpol=0, cpha=0, strength=DS_16MA, init_max_size=16384):
        self.max_size = init_max_size
        clock = sys_clk
        status = self.dev_lib.FT4222_SetClock(self.ft_handle, clock)
        if status:
            self.error = "Can not set clock: status = %d" % status
            logging.error(self.error)
            return False
        # clock_rd = DWORD(0)
        # status = self.dev_lib.FT4222_GetClock(self.ft_handle, byref(clock_rd))
        Strength = strength
        status = self.dev_lib.FT4222_SPI_SetDrivingStrength(self.ft_handle, Strength, Strength, Strength)
        if status:
            self.error = "Can not set output strength: status = %d" % status
            logging.error(self.error)
            # return False
        CLK_DIV = div_clk
        CPOL = cpol
        CPHA = cpha
        status = self.dev_lib.FT4222_SPIMaster_Init(self.ft_handle,
                                                    SPI_IO_SINGLE,  # 1 channel
                                                    CLK_DIV,  # 60 MHz / 32 == 1.875 MHz
                                                    CPOL,  # clock idles at logic 0
                                                    CPHA,  # data captured on rising edge
                                                    MASTER_SELECT)
        if status:
            self.error = "Can not init devices: status = %d" % status
            logging.error(self.error)
            return False
        max_size = c_uint32()
        status = self.dev_lib.FT4222_GetMaxTransferSize(self.ft_handle, byref(max_size))
        if status:
            self.error = "Can get GetMaxTransferSize: status = %d" % status
            logging.error(self.error)
            return False
        self.max_size = max_size.value
        logging.debug("GetMaxTransferSize = %d" % self.max_size)

        return True

    def int2bytes(self, d, d_len):
        b = bytes([int(d / (256 ** (d_len - 1))) % 256])
        if d_len >= 2:
            for i in range(2, d_len + 1):
                b += bytes([int(d / (256 ** (d_len - i))) % 256])
        return b

    def struct2bytes(self, d, d_len):
        b = d.r0
        if d_len >= 2:
            b += d.r1
        if d_len >= 3:
            b += d.r2
        if d_len >= 4:
            b += d.r3
        if d_len >= 5:
            b += d.r4
        if d_len >= 6:
            b += d.r5
        if d_len >= 7:
            b += d.r6
        if d_len >= 8:
            b += d.r7
        if d_len >= 9:
            b += d.r8
        if d_len >= 10:
            b += d.r9
        if d_len >= 11:
            b += d.r10
        if d_len >= 12:
            b += d.r11
        if d_len >= 13:
            b += d.r12
        if d_len >= 14:
            b += d.r13
        if d_len >= 15:
            b += d.r14
        if d_len >= 16:
            b += d.r15
        if d_len >= 17:
            b += d.r16
        if d_len >= 18:
            b += d.r17
        if d_len >= 19:
            b += d.r18
        if d_len >= 20:
            b += d.r19
        return b

    def master_readwrite(self, data, data_len):
        sizeTransferred = DWORD(0)
        isEndTransaction = DWORD(1)
        read_data = create_string_buffer(data_len)
        status = self.dev_lib.FT4222_SPIMaster_SingleReadWrite(self.ft_handle,
                                                               read_data,
                                                               data,
                                                               DWORD(data_len),
                                                               byref(sizeTransferred),
                                                               isEndTransaction)
        if status:
            self.error = "Can not Read Write cmd: status = %d" % status
            logging.error(self.error)
            return 0, 0
        return sizeTransferred.value, read_data.value

    def master_write(self, data, data_len):
        sizeTransferred = DWORD(0)
        isEndTransaction = DWORD(1)
        status = self.dev_lib.FT4222_SPIMaster_SingleWrite(self.ft_handle,
                                                           data,
                                                           DWORD(data_len),
                                                           byref(sizeTransferred),
                                                           isEndTransaction)
        # print("spi write status = %d, sizeTransferred = %d" % (status, sizeTransferred.value))
        if status:
            self.error = "Can not Writ data: status = %d" % status
            logging.error(self.error)
            return 0
        return sizeTransferred.value

    def spi_reset_transaction(self, spi_idx):
        status = self.dev_lib.FT4222_SPI_ResetTransaction(self.ft_handle,
                                                          UCHAR(spi_idx))
        if status:
            self.error = "Can not Writ data: status = %d" % status
            logging.error(self.error)
            return False
        return True

    def spi_cmd(self, cmd, data=0, data_len=0, retry=3):
        dummy_respon = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        cmdb = cmd
        cmd_data = cmdb + dummy_respon
        retry_count = 0
        data_r = read_buf()
        while(retry_count <= retry):
            retry_count += 1
            sizeTransferred, data_r = self.master_readwrite(cmd_data, 18)
            if sizeTransferred < 18:
                self.error = 'resave data size wrong sizeTransferred = %d, should be 18' % sizeTransferred
                logging.error(self.error)
                return False, 0
            time.sleep(0.1)
            if data_r[17] == int(cmdb[0]) + 0x10:
                if data_len:
                    if cmd == SPI_CMD_SYNC:
                        return True, 0
                    elif cmd == SPI_CMD_SEND_DATA:
                        start_time = time.time()
                        seek = 0
                        while seek + self.max_size < data_len:
                            # print("download: %d, seek = %d data_len = %d" % (int(seek* 100/data_len), seek, data_len) )
                            sizeTransferred = self.master_write(data[seek: seek + self.max_size], self.max_size)
                            if sizeTransferred != self.max_size:
                                break
                            seek += self.max_size
                        sizeTransferred = self.master_write(data[seek: data_len], data_len - seek)
                        if sizeTransferred == data_len - seek:
                            print("time use = %f" % (time.time() - start_time))
                            return True, 0
                        print("time used = %f" % (time.time() - start_time))
                    else:
                        data_b = self.int2bytes(data, data_len)
                        sizeTransferred, data_r = self.master_readwrite(data_b, data_len)
                        if sizeTransferred == data_len:
                            return True, data_r
                else:
                    return True, 0
        self.error = 'send cmd wrong'
        logging.error(self.error)
        return False, 0

    def deinit(self):
        self.dev_lib.FT4222_UnInitialize()
        self.ft_lib.FT_Close()
'''
SPI_CMD_SYNC = 0
SPI_CMD_SEND_LEN = 1
SPI_CMD_GET_LEN = 2
SPI_CMD_SEND_CHECKSUM = 3
SPI_CMD_SEND_DATA = 4
SPI_CMD_GET_CHECKSUM = 5
'''
if __name__ == '__main__':
    test_spi = FT4222_spi_master()
    test_spi.get_handle()
    test_spi.master_init(SYS_CLK_24, CLK_DIV_512, CLK_IDLE_LOW, CLK_LEADING, DS_16MA)
    test_spi.spi_cmd(SPI_CMD_SEND_CHECKSUM, 0, 0, 0)
