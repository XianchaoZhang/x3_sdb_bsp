from ctypes import *
STRING = c_char_p

DWORD = c_uint
ULONG = c_ulong
USHORT = c_ushort
SHORT = c_short
UCHAR = c_ubyte
WORD = c_ushort
BYTE = c_ubyte
LPBYTE = POINTER(c_ubyte)
BOOL = c_int
BOOLEAN = c_char
CHAR = c_char
LPBOOL = POINTER(c_int)
PUCHAR = POINTER(c_ubyte)
LPCSTR = STRING
PCHAR = STRING
PVOID = c_void_p
HANDLE = c_void_p
LONG = c_long
INT = c_int
UINT = c_uint
LPSTR = STRING
LPTSTR = STRING
LPDWORD = POINTER(DWORD)
LPWORD = POINTER(WORD)
PULONG = POINTER(ULONG)
LPVOID = PVOID
VOID = None
ULONGLONG = c_ulonglong
FT_HANDLE = POINTER(DWORD)
# FT_HANDLE = PVOID
FT_STATUS = ULONG

# List Devices flags
LIST_NUMBER_ONLY = 0x80000000
LIST_BY_INDEX = 0x40000000
LIST_ALL = 0x20000000

MAX_DESCRIPTION_SIZE = 256


class FT_DEVICE_LIST_INFO_NODE(Structure):
    _fields_ = [
        ('Flags', DWORD),
        ('Type', DWORD),
        ('ID', DWORD),
        ('LocId', DWORD),
        ('SerialNumber', c_char*16),
        ('Description', c_char*64),
        ('ftHandle', c_void_p)
    ]


class FT4222_Version(Structure):
    _fields_ = [
        ('chipVersion', DWORD),
        ('dllVersion', DWORD),
    ]


class read_buf(Structure):
    _fields_ = [
        ('r0', CHAR), ('r1', CHAR),
        ('r2', CHAR), ('r3', CHAR),
        ('r4', CHAR), ('r5', CHAR),
        ('r6', CHAR), ('r7', CHAR),
        ('r8', CHAR), ('r9', CHAR),
        ('r10', CHAR), ('r11', CHAR),
        ('r12', CHAR), ('r13', CHAR),
        ('r14', CHAR), ('r15', CHAR),
        ('r16', CHAR), ('r17', CHAR),
        ('r18', CHAR), ('r19', CHAR),
        ('r20', CHAR), ('r21', CHAR)
    ]


class write_buf(Structure):
    _fields_ = [
        ('r0', CHAR), ('r1', CHAR),
        ('r2', CHAR), ('r3', CHAR),
        ('r4', CHAR), ('r5', CHAR),
        ('r6', CHAR), ('r7', CHAR),
        ('r8', CHAR), ('r9', CHAR),
        ('r10', CHAR), ('r11', CHAR),
        ('r12', CHAR), ('r13', CHAR),
        ('r14', CHAR), ('r15', CHAR),
        ('r16', CHAR), ('r17', CHAR),
        ('r18', CHAR), ('r19', CHAR),
        ('r20', CHAR), ('r21', CHAR)
    ]

SYS_CLK_60 = DWORD(0)
SYS_CLK_24 = DWORD(1)
SYS_CLK_48 = DWORD(2)
SYS_CLK_80 = DWORD(3)

SPI_IO_NONE = DWORD(0)
SPI_IO_SINGLE = DWORD(1)
SPI_IO_DUAL = DWORD(2)
SPI_IO_QUAD = DWORD(4)

CLK_NONE = DWORD(0)
CLK_DIV_2 = DWORD(1)      # 1/2   System Clock
CLK_DIV_4 = DWORD(2)      # 1/4   System Clock
CLK_DIV_8 = DWORD(3)      # 1/8   System Clock
CLK_DIV_16 = DWORD(4)     # 1/16  System Clock
CLK_DIV_32 = DWORD(5)     # 1/32  System Clock
CLK_DIV_64 = DWORD(6)     # 1/64  System Clock
CLK_DIV_128 = DWORD(7)    # 1/128 System Clock
CLK_DIV_256 = DWORD(8)    # 1/256 System Clock
CLK_DIV_512 = DWORD(9)    # 1/512 System Clock

CLK_IDLE_LOW = DWORD(0)
CLK_IDLE_HIGH = DWORD(1)

CLK_LEADING = DWORD(0)
CLK_TRAILING = DWORD(1)

MASTER_SELECT = DWORD(1)
SLAVE_SELECT = DWORD(2)

DS_4MA = DWORD(0)
DS_8MA = DWORD(1)
DS_12MA = DWORD(2)
DS_16MA = DWORD(3)
